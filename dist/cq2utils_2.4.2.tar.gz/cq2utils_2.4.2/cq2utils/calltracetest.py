## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
#
# CallTrace can be used in test to trace the calls made by objects.
#

import unittest
import calltrace

class CallTraceTest(unittest.TestCase):

	def testSimpleCall(self):
		callTrace = calltrace.CallTrace()
		callTrace.simpleCall()
		self.assertEquals(1, len(callTrace.calledMethods))
		tracedCall = callTrace.calledMethods[0]
		self.assertEquals('simpleCall', tracedCall.name)
		self.assertEquals(0, len(tracedCall.arguments))
		
	def testCallWithArguments(self):
		callTrace = calltrace.CallTrace()
		callTrace.simpleCall('argument one', 2)
		self.assertEquals(1, len(callTrace.calledMethods))
		
		tracedCall = callTrace.calledMethods[0]
		self.assertEquals('simpleCall', tracedCall.name)
		self.assertEquals(2, len(tracedCall.arguments))
		self.assertEquals('argument one', tracedCall.arguments[0])
		self.assertEquals(2, tracedCall.arguments[1])
		
		callTrace.simpleCall('argument two', 4)
		self.assertEquals(2, len(callTrace.calledMethods))
		tracedCall = callTrace.calledMethods[1]
		self.assertEquals('simpleCall', tracedCall.name)
		self.assertEquals(2, len(tracedCall.arguments))
		self.assertEquals('argument two', tracedCall.arguments[0])
		self.assertEquals(4, tracedCall.arguments[1])
		
	def testCallWithReturnValue(self):
		callTrace = calltrace.CallTrace()
		callTrace.returnValues['simpleCall'] = 'OK'
		result = callTrace.simpleCall('argument one', 2)
		self.assertEquals('OK', result)
		
	def testCallWithException(self):
		class TestException(Exception):
			pass
		callTrace = calltrace.CallTrace()
		callTrace.exceptions['simpleCall'] = TestException('test')
		try: 
			result = callTrace.simpleCall()
			self.fail()
		except TestException, e:
			self.assertEquals('test', str(e))
		
	def testTracedCallRepresentationOneArgument(self):
		callTrace = calltrace.CallTrace()
		callTrace.simpleCall('argument one')
		self.assertEquals("simpleCall('argument one')", str(callTrace.calledMethods[0]))
		
	def testTracedCallRepresentationTwoArguments(self):
		callTrace = calltrace.CallTrace()
		callTrace.simpleCall('argument one', 2)
		self.assertEquals("simpleCall('argument one', 2)", str(callTrace.calledMethods[0]))
		
	def testTracedCallRepresentationObjectArgument(self):
		class SomeClass:
			pass
		callTrace = calltrace.CallTrace()
		callTrace.simpleCall(SomeClass())
		self.assertEquals("simpleCall(<calltracetest.SomeClass>)", str(callTrace.calledMethods[0]))
		
	def testGetList(self):
		callTrace = calltrace.CallTrace()
		callTrace.simpleCall('argument one', 2)
		self.assertEquals(["""simpleCall('argument one', 2)"""], callTrace.__calltrace__())
	
	def testNonZero(self):
		callTrace = calltrace.CallTrace()
		self.assertTrue(callTrace)		

if __name__ == '__main__':
	unittest.main()
