#!/usr/bin/env python
## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import binderytools
import unittest
from amaraextension import removeNamespaces, getElements
import wrappers

class AmaraExtensionTest(unittest.TestCase):
	
	def setUp(self):
		self.noNamespaceString = """<?xml version="1.0" encoding="UTF-8"?>\n<a> <b c="c">B</b> </a>"""
	
	def testRemoveNamespacesZero(self):
		subject = binderytools.bind_string(self.noNamespaceString)
		removeNamespaces(subject)
		self.assertEquals(self.noNamespaceString, subject.xml())
		
	def testRemoveNamespacesOne(self):
		s = """<?xml version="1.0" encoding="UTF-8"?>\n<a xmlns="http://xmlns.example.org/some.xsd"> <b c="c">B</b> </a>"""
		subject = binderytools.bind_string(s)
		removeNamespaces(subject)
		self.assertEquals(self.noNamespaceString, subject.xml())
		
	def testRemoveNamespacesWithPrefix(self):
		s = """<?xml version="1.0" encoding="UTF-8"?>\n<a xmlns:prefix="http://xmlns.example.org/some.xsd"> <prefix:b c="c">B</prefix:b> </a>"""
		subject = binderytools.bind_string(s)
		removeNamespaces(subject)
		self.assertEquals(self.noNamespaceString, subject.xml())
		
	def testRemoveNamespacesFromWrappedAmaraObject(self):
		s = """<?xml version="1.0" encoding="UTF-8"?>\n<a xmlns:prefix="http://xmlns.example.org/some.xsd"> <prefix:b c="c">B</prefix:b> </a>"""
		subject = wrappers.wrapp(binderytools.bind_string(s))
		removeNamespaces(subject)
		self.assertEquals(self.noNamespaceString, subject.xml())

	
	def testRemoveNamespacesWithPrefixOnAttributes(self):
		s = """<?xml version="1.0" encoding="UTF-8"?>\n<a xmlns:prefix="http://xmlns.example.org/some.xsd"> <b prefix:c="c">B</b> </a>"""
		subject = binderytools.bind_string(s)
		removeNamespaces(subject)
		notRemoved = '<?xml version="1.0" encoding="UTF-8"?>\n<a> <b xmlns:prefix="http://xmlns.example.org/some.xsd" prefix:c="c">B</b> </a>'
		self.assertEquals(notRemoved, subject.xml())
		
	def testRemoveNamespacesN(self):
		s = """<?xml version="1.0" encoding="UTF-8"?>\n<a xmlns="http://xmlns.example.org/some.xsd"> <b xmlns="http://xmlns.example.org/other.xsd" c="c">B</b> </a>"""
		subject = binderytools.bind_string(s)
		removeNamespaces(subject)
		self.assertEquals(self.noNamespaceString, subject.xml())
		
	def testXPathWorks(self):
		s = """<?xml version="1.0" encoding="UTF-8"?>\n<a xmlns="http://xmlns.example.org/some.xsd"> <b c="c">B</b> </a>"""
		subject = binderytools.bind_string(s)
		allBees = subject.xml_xpath('//b')
		self.assertEquals(0, len(allBees))
		removeNamespaces(subject)
		allBees = subject.xml_xpath('//b')
		self.assertEquals(1, len(allBees))
		
	def testGetElements(self):
		s = """<?xml version="1.0" encoding="UTF-8"?>\n<a>  <b/> <c/> </a>"""
		subject = binderytools.bind_string(s)
		result = getElements(subject.a)
		self.assertEquals(2, len(result))
		self.assertEquals("b", result[0].localName)
		self.assertEquals("c", result[1].localName)
		
if __name__ == '__main__':
	unittest.main()
