#!/usr/bin/python
# -*- coding: utf-8 -*-
## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest
from wrappers import WrapDict, wrapp, WrapperException
import binderytools

class StringField(str):
    """ This class is basically a string with
    a value attribute for compatibility with std lib cgi.py
    """
    
    def __init__(self, str=""):
        str.__init__(self, str)
        self.value = self.__str__()

class WrappersTest(unittest.TestCase):	

	def testUpdateDict(self):
		args={'a':['a','aa'],'b':['b']}
		argsWrap = WrapDict(args)
		argsWrap['c']=['cc']
		self.assertEquals('cc', argsWrap.c)
		self.assertEquals('', argsWrap.c.niks)
		self.assertEquals('a', argsWrap.a)
		self.assertEquals('b', argsWrap.b)
		argsWrap.update({'e':['e'],'f':'f'})
		self.assertEquals('f', argsWrap.f)
		
	def testUnicodeAmara(self):
		xml = '<?xml version="1.0" encoding="utf-8"?><a>‘Akademiehoogleraar’</a>'
		p = binderytools.bind_string(xml)
		self.assertEquals('\xe2\x80\x98Akademiehoogleraar\xe2\x80\x99', unicode(p.a).encode('utf-8'))

	def testAmaraIteration(self):
		xml = '<a><b>boter</b><b>bij</b><b>de</b><b>vis</b><d>patat</d></a>'
		p = wrapp(binderytools.bind_string(xml))
		self.assertEquals('',str(p.a.b.c))
		text = ''
		for b in p.a.b:
			text += str(b)
		self.assertEquals('boterbijdevis',text)
		for b in p.a.b:
			self.assertEquals('',str(b.c))
		ds=[]
		for d in p.a.d:
			ds.append(str(d))
		self.assertEquals(['patat'],ds)
		es=[]
		for e in p.a.e:
			es.append(e)
		self.assertEquals([],es)
		
	def testIterTwice(self):
		xml = '<a><b><c>1.1.1</c><c>1.1.2</c></b><b><c>1.2.1</c><c>1.2.2</c></b></a>'
		p = wrapp(binderytools.bind_string(xml))
		result = []
		for b in p.a.b:
			for c in b.c:
				result += [str(c)]
		self.assertEquals(['1.1.1', '1.1.2', '1.2.1', '1.2.2'], result)
				
	def testWrap(self):
		root = binderytools.bind_string('<a><b>teddy</b><b>aap</b></a>')
		w = wrapp(root)
		self.assert_( hasattr( root, 'a'))
		teddy = w.a.b
		self.assertEquals('teddy', w.a.b)
		self.assertEquals('teddy and thijs', w.a.b + ' and thijs')
		self.assertEquals('thijs and teddy', 'thijs and ' + w.a.b)
		self.assertEquals('', w.a.c)
		self.assertEquals('', w.c)
		self.assertEquals('', w.c.d.a.b.d.c.d.e.d)
		#This test changed. Is teddy always before aap ?
		self.assert_(str(root.xml_xpath('//b')[1]) in ['teddy', 'aap'])
		self.assert_(str(root.xml_xpath('//b')[0]) in ['teddy', 'aap'])
		self.assert_(str(root.xml_xpath('//b')[0]) != str(root.xml_xpath('//b')[1]))
		w.a.b.title()
		list = w.xml_xpath('//b')
		self.assert_(str(list[1]) in ['teddy', 'aap'])
		self.assertEquals('teddy', w.a.b[0]) #!!
		self.assertEquals('Teddy', w.a.b.title())
		self.assertEquals(2, w.a.b.count('d'))
		self.assertEquals(1, w.a.b[1].count('p'))

	def testBoolWrapping(self):
		root = binderytools.bind_string('<a><b>teddy</b><b>aap</b></a>')
		w = wrapp(root)
		self.assert_(bool(w))
		self.assert_(not bool(w.a)) #no text in a!
		self.assert_(bool(w.a.b))
		self.assert_(not bool(w.a.c))

	def testWrapDict(self):
		w = wrapp({'aap': 'mies', 'boom': ['vuur', 'vis']})
		self.assertEquals('mies', w['aap'])
		self.assertEquals('mies', w.aap)
		self.assertEquals(['vuur', 'vis'], w['boom'])
		b = w.boom
		self.assertEquals('vuur', b)
		self.assertEquals('ietsvuur','iets'+b)
		self.assertEquals('vuur', str(b))
		self.assertEquals('vis', w.boom[1])
		self.assertEquals(['vuur','vis'], list(w.boom))
		self.assertEquals(['vuur'], list(w.boom[0]))
		self.assertEquals(['vis'], list(w.boom[1]))
		self.assertEquals('', w.noot)
		self.assertEquals(2, w.boom[0].count('u')) #! count() on string
		self.assertEquals(0, w.noot.count('a')) #! count() on list
		self.assertEquals('mies', w['aap'])
		
	def testWrapXmlWithItemList(self):
		w = wrapp( binderytools.bind_string('<root><tag>zero</tag><tag>one</tag><tag>two</tag><other>other</other></root>'))
		self.assertEquals(['zero', 'one', 'two'], list(w.root.tag))
		one = w.root.tag[1]
		self.assertEquals('one', one)
		#BEWARE (TJ): amara logic is ['one', 'two'] == list(one)
		self.assertEquals(['one'], list(one))
		self.assertEquals('<tag>one</tag>', one.xml())
		
	def testWrapDictEditing(self):
		w = wrapp({})
		w['bloem']='mooi'
		self.assertEquals('mooi', str(w.bloem))
		
	def testWrapDictWithListValues(self):
		w = wrapp({'a':'aap','b':['noot'],'c':['mies','wim', 'zus']})
		result = []
		for i in w.c: result.append(i)
		self.assertEquals(['mies','wim', 'zus'],result)
		result = []
		for i in w.b: result.append(i)
		self.assertEquals(['noot'],result)
		result = []
		for i in w.a: result.append(i)
		self.assertEquals(['aap'],result)
	
	def someMethod(self, astring):
		self.someMethod_string = astring	
	
	def testWrapString(self):
		w = wrapp({'aap':StringField('aap')})
		self.assertEquals('aap', w.aap)
		self.assertEquals('nootaapmies', 'noot' + w.aap + 'mies')
		self.someMethod(w.aap)
		
	def testGetNonExistantTitle(self):
		root = binderytools.bind_string('<a><title>De titel</title><content>aap</content></a>')
		w = wrapp(root)
		self.assertEquals('De titel', w.a.title)
		self.assertEquals('Aap', w.a.content.title())
		self.assertEquals('', w.a.content.title.title())
		self.assertEquals('', w.a.content.title)
		self.assertEquals('', w.a.tosti.ham.kaas.curry.pepper.title)
		self.assertEquals('', w.a.content.title.title)

	def testWrapDictWithUnicode(self):
		w = wrapp({'key': u'value with unicode', u'unicodekey': 'something'})
		self.assertEquals('value with unicode', w.key)
		self.assertEquals('something', w.unicodekey)

	def testUnderstandUnicode(self):
		s = '‘Keur’' # creates utf-8 encode str (done by parser/vm?)
		self.assertEquals(str, type(s))
		self.assertEquals(str, type(s[0]))
		self.assert_('\xe2' == s[0])
		self.assert_('\x80' == s[1])
		self.assert_('\x98' == s[2])
		self.assert_('K' == s[3])
		self.assertEquals( 10, len(s))

		u = s.decode('utf-8') # decode utf-8 back to 16 bits?
		self.assertEquals(unicode, type(u))
		self.assertEquals(unicode, type(u[0]))
		self.assertEquals(u'\u2018', u[0])
		self.assertEquals(u'K', u[1])
		self.assertEquals( 6, len(u))

		e = u.encode('utf-8') # encode 16 bits into utf-8
		self.assertEquals(str, type(e))
		self.assertEquals(str, type(e[0]))
		self.assert_('\xe2' == e[0])
		self.assert_('\x80' == e[1])
		self.assert_('\x98' == e[2])
		self.assert_('K' == e[3])
		self.assertEquals( 10, len(e))

	def testWrapUnicode(self):
		w = wrapp({'key': '‘Keur der Wetenschap’'}) #utf-8 encoded string Python VM setting?
		self.assertEquals('‘Keur der Wetenschap’', w.key)
		w = wrapp({'key': u'\u2018'})
		self.assertEquals('\xe2\x80\x98', w.key)
		
	def testWrapXMLAndGetTitle(self):
		w = wrapp(binderytools.bind_string('<a><b><title>the title</title></b><c>text</c></a>'))
		self.assertEquals('Text',w.a.c.title())
		self.assertEquals('the title', w.a.b.title)
		self.assertEquals('', w.a.c.title)
		self.assertEquals('', w.a.c.d.title)

	def testWrapXML__getitem__(self):
		w = wrapp(binderytools.bind_string('<a><b><title>the title</title></b><c>text</c></a>'))
		self.assertEquals('text', w.a['c'])
	
	def testWrapXML__getitem____getitem__(self):
		w = wrapp(binderytools.bind_string('<a><b><c>ddd</c></b></a>'))
		self.assertEquals('ddd', w.a['b']['c'])
		
	def testWrapXML__getitem__withNonStr(self):
		class BehaveAsStr:
			def __str__(self): return 'c'
		w = wrapp(binderytools.bind_string('<a><b><title>the title</title></b><c>text</c></a>'))
		self.assertEquals('text', w.a[BehaveAsStr()])

	def testWrappingListAccess(self):
		w = wrapp({'a':{'b':'c','d':['e','f',{'g':'h'}]}})

		self.assertEquals('', w.d.e.f[1].a)
		self.assertEquals('f',w.a.d[1])
		self.assertEquals('h',w.a.d[2].g)
		
	def testSetValueOnWrappedXml(self):
		"""We have chosen not to implement set operations for wrappers since their meaning is not unambiguous. Consider the case of an empty Amara Root Object, on which we perform root.a.a.a = "a". What does this mean?"""
		subject = binderytools.bind_string('<a><b>initial value</b></a>')
		subject.a.b = u"amara set operation works"
		self.assertEquals(u"amara set operation works", str(subject.a.b))
		
		subject = binderytools.bind_string('<a><b>initial value</b></a>')
		wrapped = wrapp(subject)
		try:
			wrapped.a.b = u"wrapped set operation works"
			self.fail()
		except WrapperException:
			pass
		
	def testWrappBinaryData(self):
		data = chr(0x80)
		self.assertEquals('\x80', str(wrapp(data)))
		
	def testUnknownThingsAreNotWrapped(self):
		data = SomeUnknownClass()
		self.assertEquals(SomeUnknownClass, wrapp(SomeUnknownClass()).__class__)

	def testInt(self):
		args={'one': '1', 'two': '2'}
		argsWrap = WrapDict(args)
		self.assertEquals(1, int(argsWrap.one))
		self.assertEquals(2, int(argsWrap.two))
		w = wrapp(binderytools.bind_string('<three>3</three>'))
		self.assertEquals(3, int(w.three))
		
	def testStartswith(self):	
		testString = 'abcd'
		self.assertTrue(testString.startswith('a'))
		self.assertTrue(wrapp(testString).startswith('a'))
		self.assertTrue(wrapp({'test':[testString]}).test.startswith('a'))
		self.assertTrue(wrapp({'test':testString}).test.startswith('a'))
		self.assertTrue( wrapp( binderytools.bind_string('<test>%s</test>'%testString) ).test.startswith('a'))
		
	def testStringInXmlList(self):
		originalList = ['findThis', 'andThis']
		wrappedList = wrapp(originalList)
		
		originalXml = binderytools.bind_string('<root><b>findThis</b><b>andThis</b></root>').root.b
		wrappedXml = wrapp(originalXml)
		
		self.assertThingsInList(originalList)
		self.assertThingsInList(wrappedList)
		
		self.assertThingsInList(originalXml)
		self.assertThingsInList(wrappedXml)
		
		self.assertFalse('f' in originalXml)
		
	def assertThingsInList(self, aList):
		a = wrapp(binderytools.bind_string('<a>findThis</a>')).a
		self.assertTrue(a in aList)
		self.assertTrue('findThis' in aList)
		self.assertTrue('andThis' in aList)
		self.assertFalse('notThis' in aList)
		
	def testStringsInEmptyList(self):
		originalList = []
		wrappedList = wrapp(originalList)
		
		originalXml = binderytools.bind_string('<root><b/></root>').root.b
		wrappedXml = wrapp(originalXml)
		
		notThis = wrapp(binderytools.bind_string('<a>notThis</a>').a)
		
		self.assertFalse('notThis' in originalList)
		self.assertFalse('notThis' in wrappedList)
		self.assertFalse('notThis' in originalXml)
		self.assertFalse('notThis' in wrappedXml)
		self.assertFalse('notThis' in wrappedXml.nonExistingTag)
		self.assertFalse(notThis in originalList)
		self.assertFalse(notThis in wrappedList)
		self.assertFalse(notThis in originalXml)
		self.assertFalse(notThis in wrappedXml)
		
		self.assertFalse(notThis in wrappedXml.nonExistingTag)

		
	def testGetattr(self):
		a = wrapp({'a':['bb']}).a
		aDict = {'bb':'cc'}
		self.assertEquals('bb', a)
		self.assertEquals('cc', aDict[a])
		
class SomeUnknownClass:
	pass

if __name__ == '__main__': unittest.main()
