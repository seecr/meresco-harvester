# -*- encoding=utf-8 -*-

import unittest
from StringIO import StringIO

from threading import Thread
import urllib
from time import sleep
import socket
import binderytools

PORT=4321

class AmaraTestServer(Thread):
	def run(self):
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		#sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		sock.bind(('0.0.0.0', PORT))
		sock.listen(5)

		temp_buffer = ''
		remote, address = sock.accept()
		temp_buffer = remote.recv(4096)
		remote.send("""HTTP/1.0 200 OK
Date: Thu, 26 Oct 2006 11:28:52 GMT
Server: Apache/2.0.55 (Debian) mod_python/3.2.10 Python/2.4.4c0 mod_ssl/2.0.55 OpenSSL/0.9.8c
Last-Modified: Thu, 26 Oct 2006 11:28:18 -0000
Content-Type: text/xml
Connection: close

<?xml version="1.0" encoding="UTF-8"?>
<root>
  <text>Euro = \xe2\x82\xac</text>
</root>""")
		remote.close()
		sock.close()
		

class AmaraBindUriTest(unittest.TestCase):
	def setUp(self):
		server = AmaraTestServer()
		server.start()
		sleep(1)
	
	def testBindUri(self):
		b = binderytools.bind_uri('http://localhost:%i/' % PORT)
		self.assertEquals('Euro = €', str(b.root.text))

	def testBindStream(self):
		b = binderytools.bind_stream(urllib.urlopen('http://localhost:%i/' % PORT))
		self.assertEquals('Euro = €', str(b.root.text))
	