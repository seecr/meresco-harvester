## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
#
# $Id: growlclienttest.py 3154 2006-10-24 13:08:18Z svn $
#

from cq2utils.streams.readwritestream import ReadWriteStream
from StringIO import StringIO
from time import sleep
import unittest
import growlclient
from cq2utils import cq2testcase
from growlclient import GrowlException

ANSWER = """<?xml version="1.0" encoding="utf-8"?>
<results>
  <result id="%s">
    <status>%s</status>
    <message>%s</message>
  </result>
</results>"""

HEADER = """<?xml version="1.0" encoding="utf-8" ?>\n<documents>\n"""

DOCUMENT_BODY = """<partname="part1" type="text/xml">part 1 contents</part>"""

class GrowlClientTest(cq2testcase.CQ2TestCase):

	def setUp(self):
		self._sentToServer = StringIO()
		self._receivedFromServer = StringIO()
	
	def createClient(self):
		return growlclient.GrowlClient(ReadWriteStream(
			self._receivedFromServer,
			self._sentToServer))
		
	def testStart(self):
		client =  self.createClient()
		client.start()
		self.assertEquals(HEADER, self._sentToServer.getvalue())

	def testStop(self):
		self.setServerAnswer("""<?xml version="1.0" encoding="utf-8"?><results></results>""")
		client =  self.createClient()
		client.start()
		client.stop()
		self.assertEqualsWS(HEADER + '</documents>', self._sentToServer.getvalue())
		
	def testSuccessOneResult(self):
		self.setServerAnswer(ANSWER %("id", "OK", ""))
		client = self.createClient()
		client.start()
		answer = client.send('id', DOCUMENT_BODY)
		client.stop()
		self.assertEquals('OK', answer)
	
	def testFail(self):
		self.setServerAnswer(ANSWER %("id", "FAIL", "an error message"))
		
		client =  self.createClient()
		client.start()
		try:
			client.send('id', DOCUMENT_BODY)
			self.fail()
		except GrowlException, e:
			self.assertEquals('an error message', str(e))
		client.stop()

	def testMultilineFailure(self):
		self.setServerAnswer(ANSWER % ("ut:oai:purl.org:utwente/57321", "ERROR", """Traceback (most recent call last):
JavaError: java.io.IOException""")) 
		client =  self.createClient()
		client.start()
		try:
			client.send('id', DOCUMENT_BODY)
			self.fail()
		except GrowlException, e:
			self.assertEqual("""Traceback (most recent call last):
JavaError: java.io.IOException""", str(e))
			client.stop()

	
	def testTwoResults(self):
		self.setServerAnswer("""<?xml version="1.0" encoding="utf-8" ?>
	<results>
		<result id="id">
			<status>OK</status>
			<message></message>
		</result>
		<result id="id2">
			<status>FAIL</status>
			<message>an error message</message>
		</result>
	</results>""")
		
		client =  self.createClient()
		client.start()
		answer = client.send('id', DOCUMENT_BODY)
		self.assertEquals('OK', answer)
		
		try:
			client.send('id2', DOCUMENT_BODY)
			self.fail()
		except GrowlException, e:
			self.assertEquals('an error message', str(e))
		client.stop()
	
	def testSendToServer(self):
		self.setServerAnswer(ANSWER %("id", "OK", ""))
		client =  self.createClient()
		client.start()
		self.assertEqualsWS(HEADER, self._sentToServer.getvalue())
		answer = client.send('id', DOCUMENT_BODY)
		self.assertEqualsWS(HEADER + '<document id="id">' + DOCUMENT_BODY + '</document>', self._sentToServer.getvalue())

	def testclientSurvivesEmptyServer(self):
		self.setServerAnswer("")
		client =  self.createClient()
		client.start()
		try:
			client.send('id', DOCUMENT_BODY)
			self.fail()
		except GrowlException, e:
			pass
		client.stop()
	
	def testClientSurvivesRandomGarbageFromServer(self):
		self.setServerAnswer("""RANDOM GARBAGE""")
		client =  self.createClient()
		client.start()
		try:
			client.send('id', DOCUMENT_BODY)
			self.fail()
		except GrowlException, e:
			pass
		client.stop()
	
	def testIdsShouldMatch(self):
		self.setServerAnswer(ANSWER %("aDifferentId", "OK", ""))
		client =  self.createClient()
		client.start()
		try:
			client.send('anId', DOCUMENT_BODY)
			self.fail()
		except GrowlException, e:
			pass
		client.stop()
		
	def testDelete(self):
		self.setServerAnswer(ANSWER %("id", "OK", ""))
		client = self.createClient()
		client.start()
		answer = client.delete("id")
		self.assertEquals('OK', answer)
	
	def testMultipleParts(self):
		self.setServerAnswer(ANSWER %("id", "OK", ""))
		client = self.createClient()
		client.start()
		client.startDocument("id")
		stream = client.startPart("part one", "text/plain")
		stream.write("some text")
		client.stopPart()
		
		stream = client.startPart("part two", "text/plain")
		stream.write("more text")
		client.stopPart()
		result = client.stopDocument()
		client.stop()
		self.assertEquals("OK", result)
		
		self.assertEqualsWS("""<?xml version="1.0" encoding="utf-8" ?>
		<documents>
		<document id="id">
		<part name="part one" type="text/plain">some text</part>
		<part name="part two" type="text/plain">more text</part>
		</document>
		</documents>""", self._sentToServer.getvalue())
		
	def testDocumentStartStopMustMatch(self):
		client = self.createClient()
		client.start()
		client.startDocument("id")
		try:
			client.startDocument("id2")
			self.fail()
		except GrowlException:
			pass
	
	def setServerAnswer(self, answer):
		self._receivedFromServer = StringIO(answer)
		
	def _removeWhiteSpace(self, aString):
		return ''.join(aString.split())

	def assertEqualsWS(self, s1, s2):
		self.assertEquals(self._removeWhiteSpace(s1), self._removeWhiteSpace(s2))	

if __name__ == '__main__':
	unittest.main()
