#!/usr/bin/env python
## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
#
# $Id: sshservertest.py 3151 2006-10-24 06:27:34Z svn $
#

import unittest
import sshserver
import os

class ThisClassHasNoProcessMethod:
	pass

class SSHServerTest(unittest.TestCase):
	def assertNoTMPDIR(self):
		os.path.isdir(sshserver.TMPDIR) and	os.system('rm -rf ' + sshserver.TMPDIR)
		
	def setUp(self):
		self.assertNoTMPDIR()
		
	def tearDown(self):
		self.assertNoTMPDIR()
		
	def testCreateImportStatement(self):
		server = sshserver.SSHServer("cats.PersianCat")
		self.assertEquals("from cats import PersianCat", server._createImportStatement())
		
	def testImportGarbage(self):
		try:
			server = sshserver.SSHServer("notice the lack of a dot and the spaces")
			self.fail()
		except sshserver.SSHServerException, e:
			self.assertEquals("Invalid qualified classname", str(e))
			self.assertTrue(os.path.isdir('/tmp/sshserver'))
			self.assertEquals('Invalid qualified classname', open('/tmp/sshserver/' + os.listdir('/tmp/sshserver')[0]).read())
		
	def testImportNonExistingClass(self):
		try:
			server = sshserver.SSHServer("non.existing.module.NonExistingClass")
			server.main()
			self.fail()
		except sshserver.SSHServerException, e:
			self.assertEquals("No module named non.existing.module", str(e))
		
	def testImportRandomExistingClass(self):
		try:
			server = sshserver.SSHServer("cq2utils.networking.sshservertest.ThisClassHasNoProcessMethod")
			server.main()
			self.fail()
		except sshserver.SSHServerException, e:
			self.assertEquals("this constructor takes no arguments", str(e))
		
	def testCreateCallStatement(self):
		server = sshserver.SSHServer("cats.PersianCat")
		self.assertEquals("object = PersianCat(stream, self._argv)", server._createCallStatement())
		
if __name__ == '__main__':
	unittest.main()
