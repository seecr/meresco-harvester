#!/usr/bin/env python
## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
#
# $Id: osreadstream.py 3151 2006-10-24 06:27:34Z svn $
#

import os

EOF = '\4'

class OSReadStream:
	"""Wraps a file descriptor to alter read behavior. Uses os.read for its implementation - which has a number of consequences
	* osrs.read blocks until at least one byte is read.
	* osrs.read(n) may return any number [0, n] of bytes
	* osrs.read(-1) and osrs.read() are illegal calls
	
	usage: greedyIn = OSReadStream(sys.stdin.fileno())
	while true:
		s = greedyIn.read(1024)
		print s
		sleep(1)
		
	Our main usage so far: sys.stdin buffers if python is not run from tty; wrapping sys.stdin with OSReadStream makes reading greedy.
	"""
	
	def __init__(self, fdIn):
		self._fd = fdIn
		self._EOF = False

	def read(self, maxNrOfBytes = -1):
		if maxNrOfBytes == -1:
			raise Exception("OSReadStream has no support for -1 bytes")
		if self._EOF:
			return ''
		result = os.read(self._fd, maxNrOfBytes)
		if EOF in result:
			result = result[:result.index(EOF)]
			self._EOF = True
		return result
			
	def close(self):
		"""Not implemented yet"""
		pass
		
