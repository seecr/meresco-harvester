#
# Pushbind Test
#
import unittest, os
from pushbind import pushbind, PushbindException

class pushbindTest(unittest.TestCase):
	
	def testBasicWorkings(self):
		bind = pushbind('a', '<?xml version="1.0"?><b><a/></b>')
		a = bind.next()
		self.assertEquals('<a/>', a.xml())
	
	
	def testStopIteration(self):
		bind = pushbind('a', '<?xml version="1.0"?><b><a/></b>')
		bind.next()
		try:
			bind.next()
			self.fail()
		except StopIteration:
			pass
		
	def testHandleEmptyInput(self):
		"""Amara 1.0 does not fail this test but hangs, waiting for the first element 'a' (we do get an error trace on screen from the crashing other thread)"""
		bind = pushbind('a', '')
		try:
			bind.next()
			self.fail()
		except PushbindException, e:
			pass

	def testGarbage(self):
		"""Amara 1.0 does not fail this test but hangs, waiting for the first element 'a' (we do get an error trace on screen from the crashing other thread)"""
		bind = pushbind('a', 'GARBAGE')
		try:
			bind.next()
			self.fail()
		except PushbindException, e:
			pass

if __name__ == "__main__":
	unittest.main()
