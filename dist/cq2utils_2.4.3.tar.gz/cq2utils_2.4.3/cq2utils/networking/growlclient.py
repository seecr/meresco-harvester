## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
from xml.sax.saxutils import quoteattr, unescape as xmlUnEscape
import re

class GrowlException(Exception):
	pass

resultsRe = re.compile(r'(?s)(?m)<result id="(?P<id>[^"]*)">\s*<status>(?P<status>[^<]*)</status>\s*<message>(?P<message>[^<]*)</message>\s*</result>')

def writeLog(aString):
	f = open('/tmp/GrowlClient.log', 'a')
	try:
		f.write(aString)
	finally:
		f.close()

class GrowlClient:
	
	def __init__(self, aStream):
		self._stream = aStream
		self._responseBind = None
		self._currentDocumentId = None
		self._buffer = ''
		self._resultReaderInstance = None
	
	def start(self):
		try:
			self._writeHeader()
		except:
			self._stream.close()
			raise
	
	def stop(self):
		self._write('</documents>')

	def waitForServerStop(self):
		try:
			self._nextResult()
			raise GrowlException('Unexpected <result> after close')
		except StopIteration:
			pass

	def send(self, anId, documentBody):
		self.startDocument(anId)
		self._write(documentBody)
		return self.stopDocument()
		
	def _resultReader(self):
		while True:
			data = self._stream.read(1)
			if data:
				self._buffer += data
			scanResult = re.search(resultsRe, self._buffer)
			
			if scanResult:
				endIndex = scanResult.end()
				self._buffer = self._buffer[endIndex:]
				yield scanResult.groupdict()
				
			if not data:
				break
		
	def _nextResult(self):
		if self._resultReaderInstance == None:
			self._resultReaderInstance = self._resultReader()
		return self._resultReaderInstance.next()

	def _write(self, aString):
		self._stream.write(aString)
		self._stream.flush()

	def _writeHeader(self):
		self._write('<?xml version="1.0" encoding="utf-8" ?>\n<documents>\n')

	def _readResult(self, anId):
		try:
			result = self._nextResult()
		except StopIteration:
			raise GrowlException('No or invalid answer from server.')
		status = str(result['status'])
		if not status == 'OK':
			raise GrowlException(str(result['message']))
		if not anId == xmlUnEscape(str(result['id'])):
			raise GrowlException("Ids don't match (sent, received): (%s, %s)" % (anId, str(result['id'])))
		return 'OK'
		
		
	def delete(self, anId):
		self._write("""<document id=%s delete="true"/>""" % quoteattr(anId))
		return self._readResult(anId)
	
	def startDocument(self, anId):
		if self._currentDocumentId:
			raise GrowlException("Document %s must be stopped before sending document %s" % (self._currentDocumentId, anId))
		self._currentDocumentId = anId
		self._write("<document id=%s>" % quoteattr(anId) )
	
	def startPart(self, partName, partType):
		self._write("<part name=%s type=%s>" % (quoteattr(partName), quoteattr(partType)))
		return self._stream
	
	def stopPart(self):
		self._write("</part>\n")
	
	def stopDocument(self):
		self._write("</document>\n")
		result = self._readResult(self._currentDocumentId)
		self._currentDocumentId = None
		return result
