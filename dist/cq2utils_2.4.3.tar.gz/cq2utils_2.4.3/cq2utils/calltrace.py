## begin license ##
#
#    "CQ2 Utils" (cq2utils) is a package with a wide range of valuable tools.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of "CQ2 Utils".
#
#    "CQ2 Utils" is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    "CQ2 Utils" is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with "CQ2 Utils"; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
class CallTrace:
	def __init__(self, name = "CallTrace", verbose = False, returnValues = None):
		self.calledMethods = []
		self.returnValues = returnValues or {}
		self.exceptions = {}
		self._verbose = verbose
		self._name = name

	def __getattr__(self, attrname):
		return TracedCall(attrname, self)

	def __calltrace__(self):
		return map(str, self.calledMethods)

	def __nonzero__(self):
		return 1

	def __repr__(self):
		#TODO: __repr__ ook terug laten komen in calltrace
		return "<CallTrace: %s>" % self._name

	def __str__(self):
		#TODO: __str__ ook terug laten komen in calltrace
		return self.__repr__()

class TracedCall:
	def __init__(self, methodName, callTrace):
		self.name = methodName
		self._callTrace = callTrace
		self.arguments = []

	def __call__(self, *args, **kwargs):
		self._callTrace.calledMethods.append(self)
		self.arguments = list(args)
		if self._callTrace._verbose:
			print '%s.%s -> %s' % (
				self._callTrace._name,
				self.__repr__(),
				self.represent(self._callTrace.returnValues.get(self.name, None)))
		if self._callTrace.exceptions.has_key(self.name):
			raise self._callTrace.exceptions[self.name]
		return self._callTrace.returnValues.get(self.name, None)

	def represent(self, something):
		if something.__class__ == CallTrace:
			return repr(something)
		if str(type(something)) == "<type 'instance'>": #JJ/KVS: we haven't found a better way to detect objects, for example: instance(1, object) == True (which is of no help)
			return "<" + str(something.__class__) + ">"
		return repr(something)

	def __repr__(self):
		return '%s(%s)' % (self.name, ", ".join(map(self.represent, self.arguments)))
