import sys
sys.setdefaultencoding('utf-8')
