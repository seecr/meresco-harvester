#!/usr/bin/env python
## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import sys
import time
import urllib2
from lrucache import LRUCache
from threading import Lock
from cStringIO import StringIO

SECONDS_FOR_FALLBACK = 10*60 # 10 minutes

MAXFILESIZE = pow(2, 17) #c. 100k

class TooLargeException(Exception):
	pass

class CacheIter:
	def __init__(self, cachedUrl):
		self._delegateUrl = cachedUrl
		self._pos = 0
		self._buf = ''
		
	def __getattr__(self, name):
		return getattr(self._delegateUrl, name)
	
	def __hasattr__(self, name):
		return hasattr(self._delegateUrl, name)

	def __iter__(self):
		return self

	def next(self):
		self._delegateUrl.lock.acquire()
		try:
			if self._pos >= len(self._delegateUrl._getData()):
				self._delegateUrl._fetchnext()
			result = self._delegateUrl._getData()[self._pos]
		finally:
			self._delegateUrl.lock.release()
		self._pos = self._pos + 1
		return result
		
	def close(self):
		self._delegateUrl.lock.acquire()
		try:
			self._delegateUrl.close()
		finally:
			self._delegateUrl.lock.release()

	def read(self, count = sys.maxint):
		if count < 0:
			count = sys.maxint
		while count > len(self._buf):
			try:
				self._buf += self.next()
			except StopIteration:
				break
		result = self._buf[:count]
		self._buf = self._buf[count:]
		return result
		
	def readline(self, count = -1):
		try:
			return self.next()
		except StopIteration:
			return ''

	def readlines(self, count = -1):
		raise Error
	

class CachedURL:
	def __init__(self, url):
		self._delegateUrl = url
		self._data = []
		self.closed = False
		self.lock = Lock()
	
	def __getattr__(self, name):
		return getattr(self._delegateUrl, name)
	
	def __hasattr__(self, name):
		return hasattr(self._delegateUrl, name)
	
	def createHandle(self):
		return CacheIter(self)
	
	def _getData(self):
		return self._data
	
	def close(self):
		try:
			while self._fetchnext():
				pass
		except StopIteration:
			pass
		self._delegateUrl.close()
		self.closed = True

	def _fetchnext(self):
		if self.closed:
			raise StopIteration()
		buff = self._delegateUrl.next()
		self._data.append(buff)
		return buff

class URLCache:
	
	def __init__(self):
		self.cache = LRUCache(128)
		self.lock = Lock()
		self.maxfilesize = MAXFILESIZE

	def _open(self, urlstr, headers = {}):
		return urllib2.urlopen(urllib2.Request(urlstr, headers = headers))

	def _openAndSet(self, urlstr, headers):
		url = CachedURL(self._open(urlstr, headers))
		return self._basicOpenAndSet(url, urlstr, headers)
				
	def _openAndSetWithFallback(self, urlstr, headers):
		try:
			url = CachedURL(self._open(urlstr, headers))
		except urllib2.URLError:
			url, expireTimestamp = self._cacheGet(urlstr)
			expireTimestamp = expireTimestamp + SECONDS_FOR_FALLBACK
			self._cacheSet(urlstr, (url, expireTimestamp))
			return url
		
		return self._basicOpenAndSet(url, urlstr, headers)
			
	def _basicOpenAndSet(self, url, urlstr, headers):
		expiresOnTuple = url.info().getdate('expires')
		if expiresOnTuple and not headers:
			expiresOnEpoch = time.mktime(expiresOnTuple)
			self._cacheSet(urlstr, (url, expiresOnEpoch))
		else:
			self._cacheDel(urlstr)
		return url
				
	def _cacheSet(self, urlstr, value):
		self.lock.acquire()
		try:
			self.cache[urlstr] = value
		finally:
			self.lock.release()
						
	def _cacheGet(self, urlstr):
		self.lock.acquire()
		try:
			if urlstr in self.cache:
				return self.cache[urlstr]
			else:
				return None, None
		finally:
			self.lock.release()
			
	def _cacheDel(self, urlstr):
		self.lock.acquire()
		try:
			if urlstr in self.cache:
				del self.cache[urlstr]
		finally:
			self.lock.release()
	
	def get(self, urlstr, headers = {}):
		url, expiresOnEpoch = self._cacheGet(urlstr)
		if url:
			if time.mktime(time.gmtime()) > expiresOnEpoch:
				url = self._openAndSetWithFallback(urlstr, headers)
		else:
			url = self._openAndSet(urlstr, headers)
		return url.createHandle()

urlcache = URLCache()
