## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest
import account
import pwd
import grp
import getpass
from cq2utils import cq2testcase

class AuthenticationTest(cq2testcase.CQ2TestCase):
	
		def setUp(self):
			for username in ['testuser1', 'testuser2']:
				if account.exists(username):
					try:
						account.deleteAccount(username)
					except account.AccountException:
						pass
			self.min_id = account.nextFreeId()
	
		def tearDown(self):
			#Don't leave any traces.
			self.setUp()
		
		def testSystemConfig(self):
			slowfoot_group = grp.getgrnam('slowfoot')
			self.assertEquals('slowfoot', slowfoot_group[0])
			self.assertTrue(getpass.getuser() in slowfoot_group[3])

		def testCreateAccount(self):
			a = account.createAccount('testuser1', 'testpassword')
			self.assertEquals('testuser1', a.username())
			self.assertTrue(account.exists('testuser1'))
			self.assertFalse(account.exists('testuser2'))
			
			a = account.createAccount('testuser2', 'testpassword')
			self.assertEquals('testuser2', a.username())
			self.assertTrue(account.exists('testuser2'))
			
			pwdentry = pwd.getpwnam('testuser1')
			self.assertTrue(self.min_id >= 10000)
			self.assertEquals(self.min_id, pwdentry[2])
			pwdentry = pwd.getpwnam('testuser2')
			self.assertTrue(pwdentry[2] > self.min_id)
		
		def testValidUserUID(self):
			self.assertFalse(account.validUserUID('notexisting'))
			self.assertFalse(account.validUserUID('root'))
			account.createAccount('testuser1', 'testpassword')
			self.assertTrue(account.validUserUID('testuser1'))
		
		def testLoginNonExistingUser(self):
			try:
				a = account.login('', '')
				self.fail()
			except account.AccountException, e:
				self.assertEquals('Invalid username/password', str(e))
			
			try:
				a = account.login('nonexisting', 'nopassword')
				self.fail()
			except account.AccountException, e:
				self.assertEquals('Invalid username/password', str(e))
			
		def testLoginWithWithoutPassword(self):
			a = account.createAccount('testuser1', 'testpassword')
			try:
				try:
					a = account.login('testuser1', '')
					self.fail()
				except account.AccountException, e:
					self.assertEquals('Invalid username/password', str(e))
			finally:
				account.deleteAccount('testuser1')

		def testLoginWithWrongPassword(self):
			a = account.createAccount('testuser1', 'testpassword')
			try:
				try:
					a = account.login('testuser1', 'wrongpassword')
					self.fail()
				except account.AccountException, e:
					self.assertEquals('Invalid username/password', str(e))
			finally:
				account.deleteAccount('testuser1')

		def testLoginWithCorrectPassword(self):
			a = account.createAccount('testuser1', 'testpassword')
			try:
				a = account.login('testuser1', 'testpassword')
				self.assertEquals('testuser1', a.username())
			finally:
				account.deleteAccount('testuser1')

		def testDeleteAccount(self):
			a = account.createAccount('testuser1', 'testpassword')
			self.assertTrue(account.exists('testuser1'))
			account.deleteAccount('testuser1')
			self.assertFalse(account.exists('testuser1'))

		def testScaryPasswords(self):
			a = account.createAccount('testuser1', '!&<>|')
			self.assertTrue(account.exists('testuser1'))
			a = account.login('testuser1', '!&<>|')
			self.assertEquals('testuser1', a.username())
			
		def testPasswordWithQuotes(self):
			a = account.createAccount('testuser1', """'"'""")
			self.assertTrue(account.exists('testuser1'))
			a = account.login('testuser1', """'"'""")
			self.assertEquals('testuser1', a.username())
		
if __name__ == '__main__': unittest.main()
