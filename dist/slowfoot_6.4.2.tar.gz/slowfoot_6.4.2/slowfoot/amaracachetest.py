## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest, os, time
import tempfile
from amaracache import AmaraCache
from urllib import pathname2url
from urllib2 import urlopen, Request
from cStringIO import StringIO

class AmaraCacheTest(unittest.TestCase):

	def setUp(self):
		fd, path = tempfile.mkstemp()
		os.write(fd, '<?xml version="1.0"?><a>data</a>')
		os.close(fd)
		self.filename = path

	def tearDown(self):
		os.remove(self.filename)
		
	def testCache(self):
		cache = AmaraCache()
		url = urlopen('file:' + pathname2url(self.filename))
		try:
			amara0 = cache.get(url)
			self.assertEquals('data', str(amara0.a))
			url.close()
			url = urlopen('file:' + pathname2url(self.filename))
			amara1 = cache.get(url)
			url.close()
			time.sleep(1)
			open(self.filename, 'a').write('\n') # touch
			url = urlopen('file:' + pathname2url(self.filename))
			amara2 = cache.get(url)
		finally:
			url.close()
		self.assert_(amara0 == amara1)
		self.assert_(amara0 != amara2)

	def testInfoHeaders(self):
		stream = urlopen(Request('file:' + self.filename))
		info = stream.info()
		self.assert_(info.getdate('last-modified'))

	def testCacheFileStream(self):
		cache = AmaraCache()
		stream = open(self.filename)
		try:
			amara0 = cache.get(stream)
			self.assertEquals('data', str(amara0.a))
		finally:
			stream.close()
		stream = open(self.filename)
		try:
			amara1 = cache.get(stream)
			self.assert_(amara0 == amara1)
		finally:
			stream.close()
		time.sleep(1)
		f = open(self.filename, 'a')
		try:
			f.write('\n') # touch
		finally:
			f.close()
		stream = open(self.filename)
		try:
			amara2 = cache.get(stream)
			self.assert_(amara0 != amara2)
		finally:
			stream.close()

	def testStringIO(self):
		stream = StringIO('<?xml version="1.0"?><aap>mies</aap>')
		cache = AmaraCache()
		amara = cache.get(stream)
		self.assertEquals(str(amara.aap), 'mies')
		
	def testTestNoDeadlock(self):
		stream = StringIO('<?xml version="1.0"?><aap>mies</aap>')
		cache = AmaraCache()
		wrapped = DeadlockingURLWrapper(stream, cache)
		amara = cache.get(wrapped)
		self.assertEquals(str(amara.aap), 'mies')
		
class DeadlockingURLWrapper:
	def __init__(self, url, cache):
		self.__delegate = url
		self.__same_cache = cache
	
	def __getattr__(self, attr):
		return getattr(self.__delegate, attr)
	
	def __hasattr__(self, attr):
		return hasattr(self.__delegate, attr)
	
	def read(self, count = -1):
		anyOtherRequiredUrl = StringIO('<?xml version="1.0"?><aap>not important</aap>')
		self.__same_cache.get(anyOtherRequiredUrl)
		return self.__delegate.read(count)

if __name__ == '__main__': unittest.main()
