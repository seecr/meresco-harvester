## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest
from shallowsession import ShallowSession

class MockRequest:
	def __init__(self, headers = {'cookie': {'pysid': 'mysession'}}):
		self.headers_in = headers

class ShallowSessionTest(unittest.TestCase):

	def testCreate(self):
		req = MockRequest()
		s = ShallowSession(req, lambda x: {})
		s['key'] = 'value'
		self.assertEquals('value', s['key'])

	def testReadFromShallowSession(self):
		session = ShallowSession(MockRequest(headers = {}), None)
		self.assertFalse(session.has_key('username'))

	def testLazyInit(self):
		callback_called = [False]
		def callback(req):
			callback_called[0] = True
			return {}
		req = MockRequest(headers={})
		s = ShallowSession(req, callback)
		self.assertFalse(callback_called[0])
		s['key'] = 'value'
		self.assertTrue(callback_called[0])
		self.assertTrue(s.has_key('key'))

	def testIfRequestHasCookkieThenCreateRealSession(self):
		callback_called = [False]
		def callback(req):
			callback_called[0] = True
			return {'identifier': '9'}
		req = MockRequest()
		self.assertFalse(callback_called[0])
		s = ShallowSession(req, callback)
		self.assertTrue(callback_called[0])

	def testInvalidate(self):
		class MockSession:
			def invalidate(self):
				self.invalidate_called = True
		mockSession = MockSession()
		session = ShallowSession(MockRequest(), lambda x: mockSession)
		session.invalidate()
		self.assertTrue(mockSession.invalidate_called)

	def testGet(self):
		session = ShallowSession(MockRequest(headers = {}), None)
		self.assertEquals('isnotthere', session.get('username', 'isnotthere'))
		session = ShallowSession(MockRequest(), lambda x: {})
		self.assertEquals('isnotthere', session.get('username', 'isnotthere'))
		session = ShallowSession(MockRequest(), lambda x: {'username':'I'})
		self.assertEquals('I', session.get('username', 'isnotthere'))

	def testSave(self):
		class MockSession:
			def save(self):
				self.save_called = True
		mockSession = MockSession()
		session = ShallowSession(MockRequest(), lambda x: mockSession)
		session.save()
		self.assertTrue(mockSession.save_called)

	def testIgnoreSaveUnModifiedSession(self):
		class MockSession:
			def save(self):
				self.save_called = True
		mockSession = MockSession()
		session = ShallowSession(MockRequest(headers={}), lambda x: mockSession)
		session.save()
		self.assertFalse(hasattr(mockSession,'save_called'))


if __name__ == '__main__':
	unittest.main()
