#!/usr/bin/env python 
'''
magic.py
 determines a file type by its magic number

 (C)opyright 2000 Jason Petrone <jp_py@demonseed.net>
 All Rights Reserved

 Command Line Usage: running as `python magic.py file` will print
                     a description of what 'file' is.

 Module Usage:
     magic.whatis(data): when passed a string 'data' containing 
                         binary or text data, a description of
                         what the data is will be returned.

     magic.file(filename): returns a description of what the file
                           'filename' contains.
'''

import re, struct, string

__version__ = '0.1'

magic = [
  [0L, 'string', '=', 'PK\x03\x04', 'application/zip'],
  [0l, 'string', '=', '<?xml ', 'text/xml'],
  [0L, 'string', '=', 'FiLeStArTfIlEsTaRt', 'text/x-apple-binscii'],
  [0L, 'string', '=', '//', 'text/cpp'],
  [0L, 'string', '=', '#!/usr/local/bin/ae', 'text/script'],
  [0L, 'string', '=', '#! /usr/local/bin/ae', 'text/script'],
  [0L, 'string', '=', '#! /usr/local/bin/ae', 'text/script'],
  [0L, 'string', '=', '#!/bin/rc', 'text/script'],
  [0L, 'string', '=', '#! /bin/rc', 'text/script'],
  [0L, 'string', '=', '#! /bin/rc', 'text/script'],
  [0L, 'string', '=', '#! /', 'text/script'],
  [0L, 'string', '=', '#! /', 'text/script'],
  [0L, 'string', '=', '#!/', 'text/script'],
  [0L, 'string', '=', 'IIN1', 'image/tiff'],
  [0L, 'string', '=', 'MM\000*', 'image/tiff'],
  [0L, 'string', '=', 'II*\000', 'image/tiff'],
  [0L, 'string', '=', '\211PNG', 'image/x-png'],
  [1L, 'string', '=', 'PNG', 'image/x-png'],
  [0L, 'string', '=', 'GIF8', 'image/gif'],
  [0L, 'string', '=', '\361\000@\273', 'image/x-cmu-raster'],
  [0L, 'beshort', '=', 65496L, 'image/jpeg'],
  [0L, 'string', '=', 'hsi1', 'image/x-jpeg-proprietary'],
  [0L, 'string', '=', 'BM', 'image/x-bmp'],
  [0L, 'string', '=', 'IC', 'image/x-ico'],
  [0L, 'leshort', '=', 52306L, 'RLE image data,'],
  [2080L, 'string', '=', 'Microsoft Word 6.0 Document', 'text/vnd.ms-word'],
  [2080L, 'string', '=', 'Documento Microsoft Word 6', 'text/vnd.ms-word'],
  [2112L, 'string', '=', 'MSWordDoc', 'text/vnd.ms-word'],
  [0L, 'belong', '=', 834535424L, 'text/vnd.ms-word'],
  [0L, 'string', '=', 'PO^Q`', 'text/vnd.ms-word'],
  [2080L, 'string', '=', 'Microsoft Excel 5.0 Worksheet', 'application/vnd.ms-excel'],
  [2114L, 'string', '=', 'Biff5', 'application/vnd.ms-excel'],
  [1L, 'string', '=', 'WPC', 'text/vnd.wordperfect'],
  [0L, 'string', '=', '{\\\\rtf', 'Rich Text Format data,'],
  [0L, 'string', '=', '<!DOCTYPE HTML', 'text/html'],
  [0L, 'string', '=', '<!doctype html', 'text/html'],
  [0L, 'string', '=', '<HEAD', 'text/html'],
  [0L, 'string', '=', '<head', 'text/html'],
  [0L, 'string', '=', '<TITLE', 'text/html'],
  [0L, 'string', '=', '<title', 'text/html'],
  [0L, 'string', '=', '<html', 'text/html'],
  [0L, 'string', '=', '<HTML', 'text/html'],
  [0L, 'string', '=', '<!DOCTYPE', 'exported SGML document text'],
  [0L, 'string', '=', '<!doctype', 'exported SGML document text'],
  [0L, 'string', '=', '<!SUBDOC', 'exported SGML subdocument text'],
  [0L, 'string', '=', '<!subdoc', 'exported SGML subdocument text'],
  [0L, 'string', '=', '<!--', 'exported SGML document text']
]

magicNumbers = []

def strToNum(n):
  val = 0
  col = long(1)
  if n[:1] == 'x': n = '0' + n
  if n[:2] == '0x':
    # hex
    n = string.lower(n[2:])
    while len(n) > 0:
      l = n[len(n) - 1]
      val = val + string.hexdigits.index(l) * col
      col = col * 16
      n = n[:len(n)-1]
  elif n[0] == '\\':
    # octal
    n = n[1:]
    while len(n) > 0:
      l = n[len(n) - 1]
      if ord(l) < 48 or ord(l) > 57: break
      val = val + int(l) * col
      col = col * 8
      n = n[:len(n)-1]
  else:
    val = string.atol(n)
  return val
       
def unescape(s):
  # replace string escape sequences
  while 1:
    m = re.search(r'\\', s)
    if not m: break
    x = m.start()+1
    if m.end() == len(s): 
      # escaped space at end
      s = s[:len(s)-1] + ' '
    elif s[x:x+2] == '0x':
      # hex ascii value
      c = chr(strToNum(s[x:x+4]))
      s = s[:x-1] + c + s[x+4:]
    elif s[m.start()+1] == 'x':
      # hex ascii value
      c = chr(strToNum(s[x:x+3]))
      s = s[:x-1] + c + s[x+3:]
    elif ord(s[x]) > 47 and ord(s[x]) < 58:
      # octal ascii value
      end = x
      while (ord(s[end]) > 47 and ord(s[end]) < 58):
        end = end + 1
        if end > len(s) - 1: break
      c = chr(strToNum(s[x-1:end]))
      s = s[:x-1] + c + s[end:]
    elif s[x] == 'n':
      # newline
      s = s[:x-1] + '\n' + s[x+1:]
    else:
      break
  return s

class magicTest:
  def __init__(self, offset, t, op, value, msg, mask = None):
    if t.count('&') > 0:
      mask = strToNum(t[t.index('&')+1:])  
      t = t[:t.index('&')]
    if type(offset) == type('a'):
      self.offset = strToNum(offset)
    else:
      self.offset = offset
    self.type = t
    self.msg = msg
    self.subTests = []
    self.op = op
    self.mask = mask
    self.value = value
      

  def test(self, data):
    if self.mask:
      data = data & self.mask
    if self.op == '=': 
      if self.value == data: return self.msg
    elif self.op ==  '<':
      pass
    elif self.op ==  '>':
      pass
    elif self.op ==  '&':
      pass
    elif self.op ==  '^':
      pass
    return None

  def compare(self, data):
    #print str([self.type, self.value, self.msg])
    try: 
      if self.type == 'string':
        c = ''; s = ''
        for i in range(0, len(self.value)+1):
          if i + self.offset > len(data) - 1: break
          s = s + c
          [c] = struct.unpack('c', data[self.offset + i])
        data = s
      elif self.type == 'short':
        [data] = struct.unpack('h', data[self.offset : self.offset + 2])
      elif self.type == 'leshort':
        [data] = struct.unpack('<h', data[self.offset : self.offset + 2])
      elif self.type == 'beshort':
        [data] = struct.unpack('>H', data[self.offset : self.offset + 2])
      elif self.type == 'long':
        [data] = struct.unpack('l', data[self.offset : self.offset + 4])
      elif self.type == 'lelong':
        [data] = struct.unpack('<l', data[self.offset : self.offset + 4])
      elif self.type == 'belong':
        [data] = struct.unpack('>l', data[self.offset : self.offset + 4])
      else:
        #print 'UNKNOWN TYPE: ' + self.type
        pass
    except:
      return None
  
#    print str([self.msg, self.value, data])
    return self.test(data)
    

def load(file):
  global magicNumbers
  lines = open(file).readlines()
  last = { 0: None }
  for line in lines:
    if re.match(r'\s*#', line):
      # comment
      continue
    else:
      # split up by space delimiters, and remove trailing space
      line = string.rstrip(line)
      line = re.split(r'\s*', line)
      if len(line) < 3:
        # bad line
        continue
      offset = line[0]
      type = line[1]
      value = line[2]
      level = 0
      while offset[0] == '>':
        # count the level of the type
        level = level + 1
        offset = offset[1:]
      l = magicNumbers
      if level > 0:
        l = last[level - 1].subTests
      if offset[0] == '(':
        # don't handle indirect offsets just yet
        print 'SKIPPING ' + string.join(list(line[3:]))
        pass
      elif offset[0] == '&':
        # don't handle relative offsets just yet
        print 'SKIPPING ' + string.join(list(line[3:]))
        pass
      else:
        operands = ['=', '<', '>', '&']
        if operands.count(value[0]) > 0:
          # a comparison operator is specified
          op = value[0] 
          value = value[1:]
        else:
          print str([value, operands])
          if len(value) >1 and value[0] == '\\' and operands.count(value[1]) >0:
            # literal value that collides with operands is escaped
            value = value[1:]
          op = '='

        mask = None
        if type == 'string':
          while 1:
            value = unescape(value)
            if value[len(value)-1] == ' ' and len(line) > 3:
              # last value was an escaped space, join
              value = value + line[3]
              del line[3]
            else:
              break
        else:
          if value.count('&') != 0:
            mask = value[(value.index('&') + 1):]
            print 'MASK: ' + mask
            value = value[:(value.index('&')+1)]
          try: value = strToNum(value)
          except: continue
          msg = string.join(list(line[3:]))
        new = magicTest(offset, type, op, value, msg, mask)
        last[level] = new
        l.append(new)

def whatis(data):
  for test in magicNumbers:
     m = test.compare(data)
     if m: return m
  # no matching, magic number. is it binary or text?
  for c in data:
    if ord(c) > 128:
      return 'data'
  return 'text/plain'
      
    
def file(file):
  try:
    return whatis(open(file, 'r').read(8192))
  except Exception, e:
    if str(e) == '[Errno 21] Is a directory':
      return 'directory'
    else:
      raise e
  

#### BUILD DATA ####
#load('mime-magic')
#f = open('out', 'w')
#for m in magicNumbers:
#  f.write(str([m.offset, m.type, m.op, m.value, m.msg]) + ',\n')
#f.close

import sys
for m in magic:
  magicNumbers.append(magicTest(m[0], m[1], m[2], m[3], m[4]))

if __name__ == '__main__':
  import sys
  for arg in sys.argv[1:]:
    msg = file(arg)
    if msg:
      print arg + ': ' + msg
    else:
      print arg + ': unknown'
