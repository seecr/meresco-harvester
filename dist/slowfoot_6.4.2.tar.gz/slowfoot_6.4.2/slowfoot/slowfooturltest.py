## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import unittest, tempfile
from urllib import pathname2url
from slowfooturl import SlowfootURL, uri
from mytestcase import MyTestCase
import slowfooturl

class SlowfootURLTest(MyTestCase):

	def testIsXmlOnStream(self):
		open(self.testdir+'/astream', 'w').write('<?xml and some things follow')
		url = SlowfootURL('file:'+self.testdir+'/astream')
		try:
			self.assert_(url.xml)
			result = ''
			for c in url:
				result += c
			self.assertEquals('<?xml and some things follow', result)
		finally:
			url.close()
		
	def testNoXML(self):
		open(self.testdir+'/astream', 'w').write('different')
		url = SlowfootURL('file:'+self.testdir+'/astream')
		try:
			self.assert_(not url.xml)
			result = ''
			for c in url:
				result += c
			self.assertEquals('different', result)
		finally:
			url.close()
		
	def testReadMethod(self):
		self.tempDataFileWithGC('different', 'astream')
		url = SlowfootURL('file:' + self.testdir + '/data/astream')
		try:
			self.assertEquals('different', url.read(10))
		finally:
			url.close()
		
	def testGeturl(self):
		self.tempDataFileWithGC('', 'astream')
		url = SlowfootURL('file:' + self.testdir + '/data/astream')
		try:
			self.assertEquals('file:' + self.testdir + '/data/astream', url.geturl())
		finally:
			url.close()

	def testInfo(self):
		open(self.testdir+'/astream', 'w').write('<?xml and some things follow')
		url = SlowfootURL('file:'+self.testdir+'/astream')
		try:
			self.assert_(url.info())
		finally:
			url.close()		

	def testOpenUrl(self):
		open(self.testdir+'/data/xmlfile', 'w').write('<?xml version=1.0>\r<a></a><xml?>')
		from urllib2 import urlopen
		try:
			urlopen('file:'+self.testdir+'/plaiKJGUY')
			self.fail()
		except:
			pass
		url = SlowfootURL('file:'+self.testdir+'/data/xmlfile')
		self.assert_(url.xml)
	
	def testReadEverything(self):
		name = 'testGarbageWithRead'
		self.tempDataFileWithGC('firstline\nnextline\nanotherline', name)
		url = SlowfootURL('file:' + self.testdir + '/data/' + name)
		self.assertEquals('firstline\nnextline\nanotherline',url.read())
		
	def testRead4(self):
		name = 'testGarbageWithRead'
		self.tempDataFileWithGC('firstline\nnextline\nanotherline', name)
		url = SlowfootURL('file:' + self.testdir + '/data/' + name)
		try:
			self.assertEquals('firs',url.read(4))
			self.assertEquals('tlin', url.read(4))
			self.assertEquals('e\nne', url.read(4))
			self.assertEquals('xtline\nanotherline', url.read())
		finally:
			url.close()
		

	def testOpenWithUniversalNewline(self):
		name = self.testdir + '/testOpenWithUniversalNewline'
		f = open(name, 'wb') # binary! otherwise \r\n becomes \r\r\n
		try:
			f.write('aap\r\nnoot\rmies\nboom')
			f.close()
			url = SlowfootURL('file:' + name)
			part1 = url.read(6)
			self.assertEquals('aap\nno', part1)
			part2 = url.read()
			self.assertEquals('ot\nmies\nboom', part2)
		finally:
			url.close()
			import os
			os.remove(name)

	def testOpenImage(self):
		gifje = 'GIF89a:\x00\'\x00\xa5\x00\x00;\n\x08I\x1c\x12R%\x15d<<|9)\x99U9\xaagJ\xc1\x87k\xb5xW\xd5\xa4\x84\xdf\xb4\xa2\xae\r\n\x82d\xe2\xbb\xaa\xdc\xab\x93\xa5\xa5\xa6\xb8\xb8\xb8\xc6\xc6\xc7\xe9\xe9\xe9e-"\xc9\x94p\xd2'
		self.tempDataFileWithGC(gifje, 'gifje.gif', mode='wb')
		path = self.testdir + '/data/gifje.gif'
		try:
			url = SlowfootURL('file:' + path)
			self.assertEquals(url.read(), gifje)
		finally:
			url.close()

	def testOpenAnyBinaryFile(self):
		jpegje = '\xff\xd8\xff\xe0\x00\x10JFIF\x00\r\n\x01\x01\x01,\x01,\x00\x00\xff\xdb\x00C\x00\x08\x06\x06\x07\x06\x05\x08\x07\x07\x07\t\t\x08\n'
		self.tempDataFileWithGC(jpegje, 'jpegje.jpg', mode='wb')
		path = self.testdir + '/data/jpegje.jpg'
		try:
			url = SlowfootURL('file:' + path)
			self.assertEquals(url.read(), jpegje)
		finally:
			url.close()
		
	def testOpenSomeTextFile(self):
		textje = '<%text%>text\r\ntext\n'
		self.tempDataFileWithGC(textje, 'textje', mode = 'wb')
		path = self.testdir + '/data/textje'
		try:
			url = SlowfootURL('file:' + path)
			self.assertEquals(url.read(), '<%text%>text\ntext\n')
			self.assertEquals('text/plain', url.mimetype)
		finally:
			url.close()

	def testUndoBullShitOfUrllib2urlopen(self):
		self.tempDataFileWithGC('\r\n', 'rrn')
		try:
			url = SlowfootURL('file:' + self.testdir + '/data/rrn')
			self.assertEquals(url.read(), '\n')
		finally:
			url.close()
		
	def testCreateUrlHostAndSimplePath(self):
		self.assertEquals('file://host:80/path', uri('file', 'host:80', 'path'))
		self.assertEquals('http://w.h.nl/a/n', uri('http', 'w.h.nl', 'a/n'))
	
	def testCreateUrlWithHardPath(self):
		self.assertEquals('ftp://host/a%3F%26%3D%2B%24%2C', uri('ftp', 'host', 'a?&=+$,'))

	def testCreateUrlWithData(self):
		#Within a query component, the characters ";", "/", "?", ":", "@", "&", "=", "+", ",", and "$" are reserved.
		self.assertEquals('file://h?arg=value', uri('file', 'h', query = [('arg', 'value')]))
		self.assertEquals('file://h?%3B%2F%3F%3A%40=%26%3D%2B%2C%24', uri('file', 'h', query = {';/?:@': '&=+,$'}))
			
	def testAsDictionary(self):
		result = slowfooturl.asDictionary('testen=goed')
		self.assert_(len(result) == 1)
		
if __name__ == '__main__': unittest.main()
