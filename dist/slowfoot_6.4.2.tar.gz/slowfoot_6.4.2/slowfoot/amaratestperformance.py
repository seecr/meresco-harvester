## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import unittest
from cq2utils import binderytools
from time import clock
from urllib2 import urlopen

class AmaraPerformanceTest(unittest.TestCase):

	def XtestReadSmallString(self):
		xml = '<?xml version="1.0"?><a><b>Aap</b></a>'
		n = 100
		t0 = clock()
		for i in range(1, n):
			a = binderytools.bind_string(xml)
			self.assertEquals('Aap', str(a.a.b))
		t1 = clock()
		print ((t1 - t0) * 1000.0) / n, 'ms/binding'
		
	def testReadAndParseStream(self):
		tmp = ''
		n = 10
		t0 = clock()
		for i in range(1, n):
			stream = urlopen('file:/home/erik/development/slowfoot/data/repositories.xml')
			a = binderytools.bind_stream(stream)
			for institute in a.data.institution:
				tmp = tmp + str(institute.repository.url)
		t1 = clock()
		print ((t1 - t0) * 1000.0) / n, 'ms/binding'

	def testReadStream(self):
		n = 100
		t0 = clock()
		for i in range(1, n):
			stream = urlopen('file:/home/erik/development/slowfoot/data/repositories.xml')
			xml = stream.read()
		t1 = clock()
		print ((t1 - t0) * 1000.0) / n, 'ms reading stream'
		
	def testCacheURL(self):
		import email.Utils
		stream = urlopen('file:/home/erik/development/slowfoot/data/repositories.xml')
		info = stream.info()
		date = info['last-modified']
		self.assertEquals('Wed, 20 Apr 2005 08:01:15 GMT', date)
		d = email.Utils.parsedate(date)
		self.assert_((2005, 4, 20, 8, 1, 16, 0, 0, 0) > (2005, 4, 20, 8, 1, 15, 0, 0, 0))

	def testAmaraCache(self):
		import amaracache
		cache = amaracache.AmaraCache()
		stream = urlopen('file:/home/erik/development/slowfoot/data/repositories.xml')
		n = 100
		tmp = ''
		t0 = clock()
		for i in range(1, n):
			a = cache.get(stream)
			for institute in a.data.institution:
				tmp = tmp + str(institute.repository.url)
		t1 = clock()
		print ((t1 - t0) * 1000.0) / n, 'ms reading stream using cache'

if __name__ == '__main__':	
	unittest.main()
