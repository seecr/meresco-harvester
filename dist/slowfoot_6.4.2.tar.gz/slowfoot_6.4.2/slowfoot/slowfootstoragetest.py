#!/usr/bin/env python
## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

from slowfootstorage import SlowfootStorage
from tempfile import mkdtemp
import unittest, shutil, os

class SlowfootStorageTest(unittest.TestCase):
	def setUp(self):
		self.tempdir = mkdtemp()
		os.makedirs(os.path.join(self.tempdir, 'data'))
		self.storage = SlowfootStorage(self.tempdir)
		
	def tearDown(self):
		shutil.rmtree(self.tempdir, ignore_errors=True)
		
	def testFullPath(self):
		self.assertEquals(os.path.join(self.tempdir, 'data', 'aFilename'), self.storage.getFullPath('aFilename'))
		#Special page not existing
		self.assertEquals(os.path.join(self.tempdir, 'data', 'edit'), self.storage.getFullPath('edit'))
		
		#special page exists
		open(os.path.join(self.tempdir, 'edit'), 'w').close()
		self.assertEquals(os.path.join(self.tempdir, 'edit'), self.storage.getFullPath('edit'))
		
		#Special case for target('/data/aFilename')
		self.assertEquals(os.path.join(self.tempdir, 'data', 'aFilename'), self.storage.getFullPath('/data/aFilename', 'w'))
		
	def testFullPathAndTemplateDir(self):
		os.makedirs(os.path.join(self.tempdir, 'templates'))
		
		self.assertEquals(os.path.join(self.tempdir, 'data', 'aFilename'), self.storage.getFullPath('aFilename'))
		
		open(os.path.join(self.tempdir, 'templates', 'aFilename'), 'w').close()
		
		self.assertEquals(os.path.join(self.tempdir, 'templates', 'aFilename'), self.storage.getFullPath('aFilename'))
		
	def testFullPathWritingAlwaysInData(self):
		os.makedirs(os.path.join(self.tempdir, 'templates'))
		open(os.path.join(self.tempdir, 'templates', 'aFilename'), 'w').close()
		
		self.assertEquals(os.path.join(self.tempdir, 'data', 'aFilename'), self.storage.getFullPath('aFilename', 'w'))
		
		
		
if __name__ == '__main__':
	unittest.main()
