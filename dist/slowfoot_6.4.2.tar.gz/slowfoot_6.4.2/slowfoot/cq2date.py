## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
import time
import rfc822
from datetime import tzinfo, timedelta, datetime

ZERO = timedelta(0)

class UTC(tzinfo):

	def utcoffset(self, dt):
		return ZERO

	def tzname(self, dt):
		return "UTC"

	def dst(self, dt):
		return ZERO
	
def gmtNow():
	return GMTDate(time.gmtime())

class GMTDate:
	"""Represents a date in the GMT timezone
	JUST GMT

	REALLY:
	DO NOT USE THIS FOR ANYTHING BUT GMT!
	"""
	
	def __init__(self, aTuple):
		self._floatValue = time.mktime(aTuple) - time.timezone
	
	def asRfc822(self):
		return rfc822.formatdate(self._floatValue)
	
	def asFloat(self):
		return self._floatValue
	
	def addSeconds(self, seconds):
		self._floatValue = self._floatValue + seconds
		
	def asTuple(self):
		d = datetime.fromtimestamp(self._floatValue, UTC())
		return (d.year, d.month, d.day, d.hour, d.minute, d.second, 0,0,0)
