#!/usr/bin/env python
## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import unittest
from urlcache import URLCache, CachedURL
from cStringIO import StringIO

filecontents = """A temporary file.
with multiple
lines
with multiple
lines
with multiple
lines
with multiple
lines"""

filecontents2 = """1A temporary file.
2with multiple
3lines
4with multiple
5lines
6with multiple
7lines
8with multiple
9lines"""


class CachedURLTest(unittest.TestCase):
		
	def testURLWrapper(self):
		stream = StringIO(filecontents)
		i = CachedURL(stream)
		self.assertEquals('A t', i.createHandle().read(3))
		self.assertEquals(len("A temporary file.\n"), stream.tell())
		hand = i.createHandle()
		self.assertEquals('A t', hand.read(3))
		self.assertEquals(len("A temporary file.\n"), stream.tell())
		self.assertEquals('emporary file.\nwith ', hand.read(20))
		self.assertEquals(len("A temporary file.\nwith multiple\n"), stream.tell())
		
	def testRead20Characters(self):
		stream = StringIO(filecontents)
		i = CachedURL(stream)
		self.assertEquals('A temporary file.\nwi', i.createHandle().read(20))
	
	def testRead20FromShortStream(self):
		stream = StringIO('abc')
		i = CachedURL(stream)
		self.assertEquals('abc', i.createHandle().read(20))
	
	def testRead(self):
		stream = StringIO('abcfleuiwafh')
		i = CachedURL(stream)
		self.assertEquals('abcfleuiwafh', i.createHandle().read())
	
	def testReadInfinite(self):
		stream = StringIO('abcfleuiwafh')
		i = CachedURL(stream)
		self.assertEquals('abcfleuiwafh', i.createHandle().read(-1))
		
	def testReadline(self):
		stream = StringIO('abc\nfleui\nwafh')
		handle = CachedURL(stream).createHandle()
		self.assertEquals('abc\n', handle.readline())
		self.assertEquals('fleui\n', handle.readline())
		self.assertEquals('wafh', handle.readline())
		self.assertEquals('', handle.readline())
		
	def testReadlineEmptyStream(self):
		stream = StringIO('')
		handle = CachedURL(stream).createHandle()
		self.assertEquals('', handle.readline())
		try:
			handle.next()
			self.fail()
		except StopIteration:
			pass
		self.assertEquals('', handle.readline())
	
	def testIterAll(self):
		results = []
		stream = StringIO('abc\nfleui\nwafh')
		for line in CachedURL(stream):
			results.append(line)
		self.assertEquals(3, len(results))
		self.assertEquals('abc\n', results[0])
		self.assertEquals('fleui\n', results[1])
		self.assertEquals('wafh', results[2])
		
	def testNextAndReadMix(self):
		stream = StringIO(filecontents2)
		i = CachedURL(stream)
		handle = i.createHandle()
		self.assertEquals('1A t', i.read(4))
		self.assertEquals('emporary file.\n', i.next())
		self.assertEquals('2with multiple\n' , i.next())
		self.assertEquals('3lin', i.read(4))


if __name__ == '__main__':
	unittest.main()
	
