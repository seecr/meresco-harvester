#!/bin/sh
## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
# Copyright Seek You Too BV

set -o errexit

basedir=$(cd $(dirname $0); pwd)
slowfootdir=$(cd $basedir/..; pwd)
source $basedir/functions.sh

message 'Installing Slowfoot dependencies'

# compile the suidwrappers slowfoot uses for account creation
(
  cd $slowfootdir/suidwrapper
  make
  ./fixperms.sh
)

message "Installing required packages."

if isSuSE ; then
	which python2.4 || $PM_INSTALL python
	test -d /usr/lib/python2.4/xml || $PM_INSTALL python-xml
	test -e /usr/include/python2.4/Python.h || $PM_INSTALL python-devel
	which apache2ctl && apache2ctl -l | grep worker || $PM_INSTALL apache2-worker
	test -d /usr/include/apache2 || $PM_INSTALL apache2-devel
	which make || $PM_INSTALL make
	which gcc || $PM_INSTALL gcc
	
	mv /usr/lib/python2.4/distutils/distutils.cfg /tmp
	sh install_4suite.sh
	mv /tmp/distutils.cfg /usr/lib/python2.4/distutils/distutils.cfg

	sh install_amara_1.0.sh
elif isDebian ; then 	
	$PM_INSTALL python2.4 python2.4-dev python-xml apache2-dev flex  make gcc apache2-mpm-worker
	aptitude_install http://ftp.nl.debian.org/debian/ testing non-free python-profiler
	aptitude_install http://debian.cq2.org/ stable main python-amara1.1.7
	# The link to python should be done in the following way.
	# Else python-central can't find the correct default_version.
	(cd /usr/bin; ln -sf python2.4 python)
elif isFedora ; then
	$PM_INSTALL python python-devel httpd httpd-devel mod_ssl flex make gcc python-4Suite-XML python-amara
	mv /usr/sbin/httpd /usr/sbin/httpd.prefork
	ln -s /usr/sbin/httpd.worker /usr/sbin/httpd
fi

sh $(dirname $0)/install_mod_python_3.2.10.sh
