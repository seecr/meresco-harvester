## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import urllib2, re, httplib, string
from urllib import pathname2url, urlencode
from cStringIO import StringIO
from itertools import chain

from magicstream import MagicStream
from urlparse import urlsplit, urlunsplit
from urlcache import urlcache

def uri(scheme = '', authority = '', path = '', query = [], fragment = ''):
	return urlunsplit((scheme,authority, pathname2url(path), urlencode(query), fragment))

def asDictionary(aString):
	result = {}
	
	if aString == '':
			return result
	
	pairs = string.split(aString, '&')
	for pair in pairs:
		items =string.split(pair, '=')
		result[items[0]] = items[1]
	return result

	
class SlowfootURL:
	def __init__(self, url, headers = {}):
		scheme, self.authority, self.path, self.query, self.fragment = urlsplit(url)
		self.urlTail = uri(path=self.path, query=asDictionary(self.query), fragment=self.fragment)
			
		self.headers = headers
		stream = urlcache.get(url, headers = headers)
		self.geturl = stream.geturl
		self.info = stream.info
		self.stream = MagicStream(stream)
		self.read = self.stream.read
		self.next = self.stream.next
		self.close = self.stream.close
		self.xml = self.stream.xml
		self.mimetype = self.stream.mimetype
		self.__iter__ = self.stream.__iter__

	def post(self, value):
		conn = httplib.HTTPConnection(self.authority)
		try:
			del(self.headers['Content-Length'])
			del(self.headers['Host'])			
		except:
			pass
		conn.request('POST', self.urlTail, value, self.headers)
		return conn.getresponse()
