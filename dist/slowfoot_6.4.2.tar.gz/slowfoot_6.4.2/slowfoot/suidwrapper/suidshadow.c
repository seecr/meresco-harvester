/*
 * Wrapper for peeking in the shadow file
 *
 * $Id: $
 *
 */
/* begin license *
 * 
 *     Slowfoot is an integration system for web-based applications.
 *     Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
 * 
 *     This file is part of Slowfoot.
 * 
 *     Slowfoot is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 * 
 *     Slowfoot is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 * 
 *     You should have received a copy of the GNU General Public License
 *     along with Slowfoot; if not, write to the Free Software
 *     Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * end license */

/*
 * Return values:
 *	0 - succeeded
 *	1 - failed 
 *	2 - not found
 *  3 - wrong arguments 
 *	4 - unable to open shadowfile
 */

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <crypt.h>

int validateUser(char *username, char *password) {
	char buffer[1024];
	char *token;
	FILE *fd;
	
	setuid(0);
	
	if ((fd = fopen("/etc/shadow","r")) == NULL) {
		return 4;
	}
	while(!feof(fd)) {
		fgets(buffer, 1024, fd);
		token = strtok(buffer, ":");
		if (!strcasecmp(token, username)) {
			token = strtok(NULL, ":");
			return (!strcmp(crypt(password, token), token)) ? 0 : 1;
		}
	}
	fclose(fd);
	return 2;
}

int main(int argc, char **argv) {
	return (argc < 3) ? 3 : validateUser(argv[1], argv[2]);
}
