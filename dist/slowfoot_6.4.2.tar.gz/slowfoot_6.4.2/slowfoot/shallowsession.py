## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##
class ShallowSession:
	def __init__(self, req, retrieveSession):
		self.req = req
		self.retrieveSession = retrieveSession
		if req.headers_in.has_key('cookie') and req.headers_in['cookie'].has_key('pysid'):
			self.session = self.retrieveSession(self.req)
		else:
			self.session = None

	def __setitem__(self, key, value):
		if self.session == None:
			self.session = self.retrieveSession(self.req)
		self.session[key] = value

	def __getitem__(self, key):
		return self.session[key]

	def has_key(self, name):
		if self.session:
			return self.session.has_key(name)
		return False

	def get(self, name, default=None):
		if self.session:
			return self.session.get(name, default)
		return default

	def save(self):
		if self.session:
			self.session.save()

	def invalidate(self):
		if self.session:
			self.session.invalidate()
