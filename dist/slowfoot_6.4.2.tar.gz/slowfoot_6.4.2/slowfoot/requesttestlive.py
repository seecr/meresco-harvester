## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

#from requesttest import *
import requesttest
import time, string
import unittest
from StringIO import StringIO

class RequestTestLive(requesttest.RequestTest):
	"""This means all original tests are run as well, a base class can be factored out later"""

	def testPSPPost(self):
		import amaracache
		stream = self.req._psp_post('http://localhost/echo', StringIO('Joop'))
		try:
			self.assertEquals('http://localhost/echo', amaracache.getKeyFor(stream))
			self.assertEquals(str(time.time())[:9], str(amaracache.getDateFor(stream))[:9])
			self.assertEquals('echo: Joop\n', stream.read())
			self.assertEquals([stream], self.req.openfiles)
		finally:
			stream.close()

	def testPSPPostString(self):
		stream = self.req._psp_post('http://localhost/echo', 'Joop')
		self.assertEquals('', str(stream))

	def testPSPPostHeaders(self):
		self.req.headers_in['extraheader'] = 'forwardwithpost'
		result = self.req._psp_post('http://localhost/echo-headers', StringIO(''))
		self.req._psp_include(result)
		result = ''.join(self.result)
		self.assert_('extraheader: forwardwithpost' in result, result)
		
	def testContentLength(self):
		result = self.req._psp_post('http://localhost/testcalltemplate', StringIO('12345'))
		self.req._psp_include(result)
		items = string.split(self.result[0], '|')
		
		found = 0
		for item in items:
			if item[0:14] == 'Content-Length':
				self.assertEquals('Content-Length: 5', item)
				found = 1
		self.assert_("Content-length not found in header", found == 0)

if __name__ == '__main__':
	unittest.main()
