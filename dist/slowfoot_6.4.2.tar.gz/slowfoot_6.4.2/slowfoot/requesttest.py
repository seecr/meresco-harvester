## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

def setMockModulesPathForModPython():
	import sys
	sys.path.insert(0, "./testlib")

setMockModulesPathForModPython()
from mod_python import apache

import tempfile, os, time, email, string
from StringIO import StringIO
from cgi import parse_qs
from email.Utils import formatdate, mktime_tz
from urllib2 import urlopen
from urllib import pathname2url
from request import Request, parseUri, parseIncludeUri, getModifiedDate, getModifiedDateFromHeader, PREOPEN, isUrl
from mytestcase import MyTestCase
import re
from cq2utils.wrappers import wrapp
import account

class RequestTest(MyTestCase):

	def initShunts(self):
		self.args = ""
		self.headers_in = HeadersDict()
		self.method = ''
		self.connection = None
		self.server = None
		self.register_cleanup = None
		self.hlist = None
		self.headers_out = HeadersDict()
		self.err_headers_out = HeadersDict()
		self.get_options = None
		self.log_error = None
		self.user = ''

	def setUp(self):
		self.initShunts()
		super(RequestTest, self).setUp()
		self.slowfootdata = self.document_root() + '/data'
		os.path.isdir(self.slowfootdata) or os.makedirs(self.slowfootdata)
		self.uri = '/aap'
		self.filename = None
		self.result = []
		self.handlepsp_templatefiles = []
		self.handlepsp_template = []
		self.handlepsp_data = []
		mockReq = self
		mockUtil = self
		self.req = Request(mockReq, self.handlepsp, mockUtil, self.login, self.sessionRetrieve)

	def testParseNothing(self):
		templates, file = parseUri('/')
		self.assertEquals(['index.html'], templates)
		self.assertEquals(None, file)

	def testParseOneTemplate(self):
		templates, file = parseUri('/template')
		self.assertEquals(['template'], templates)
		self.assertEquals(None, file)
		
	def testParseUriOneTemplateOneDatafile(self):
		templates, filename = parseUri('/template/filename')
		self.assertEquals((['template'], 'filename'), (templates, filename))

	def testParseUriMoreTemplatesOneDatafile(self):
		templates, filename = parseUri('/template1/template2/file')
		self.assertEquals(['template1', 'template2'], templates)
		self.assertEquals('file', filename)
	
	def XtestParseUriWithTemplatesAndDatafilesInSubDirectories(self):
		templates, filename = parseUri('/template1/dir/template2/dir2/file')	
		self.assertEquals(['template1', 'dir/template2'], templates)
		self.assertEquals('dir2/file', filename)
	
	def testParseIncludeUri(self):
		self.assertEquals(['/uri',''],parseIncludeUri('/uri'))
		self.assertEquals(['/uri','a=b'],parseIncludeUri('/uri?a=b'))
		self.assertEquals(['/uri',''],parseIncludeUri('/uri?'))
		uri,args=parseIncludeUri('/uri?a=b')
		self.assertEquals(('/uri','a=b'),(uri,args))

	# self shunt attributes
	def write(self, text, *args):
		self.result.append(str(text))
	
	def flush(self):
		self.calledFlush = True
	
	def document_root(self):
		return self.testdir
	
	def readline(self):
		return self.readlineResult

	def handlepsp(self, target, templatefilename, data):
		template = open(templatefilename).read()
		self.handlepsp_templatefiles.append(templatefilename)
		self.handlepsp_template.append(template)
		self.handlepsp_data.append(data)
		lines = template.split('<%%>')
		target.write(lines[0])
		if len(lines) == 2:
			target.write(data['text'])
			target.write(lines[1])
		#target.write(template.replace('<%%>', data['text']))

	def parse_qs(self, something):
		result = {}
		for k,v in parse_qs(something).items():
			result[k] = len(v)==1 and v[0] or v
		return result

	def get_basic_auth_pw(self):
		return None
		
	def login(self):
		pass

	def sessionRetrieve(self, request):
		return {}

	# test mimic Apache Request
	def testWriteAcceptsFlushArg(self):
		self.req.write('schrijf', 0)
		self.assertEquals('schrijf', self.result[0])
		
	def testFlush(self):
		self.req.flush()
		self.assert_(self.calledFlush)
	
	def testHandleOneTemplateWithoutDataFile(self):
		self.tempDataFileWithGC('hel<%%>lo!', 'template')
		self.req.handle('/template', {'args': {}})
		self.assertEquals('hel<%%>lo!', self.handlepsp_template[0])
		self.assert_('last-modified' not in self.headers_out)
	
	class MockIllegalFilePlugin:
		def handle(self, req, path):
			if 'illegal' in path:
				raise IOError(2,"No such file or directory: '%s'"%path)			
		
	def testHandleOneIllegalFile(self):
		self.req.addPlugin(PREOPEN,self.MockIllegalFilePlugin())
		self.tempDataFileWithGC('do not read this', 'illegalfile')
		self.tempDataFileWithGC('read this', 'legalfile')
		try:
			self.req.handle('/illegalfile', {'args': {}})
			self.fail()
		except IOError, e:
			self.assertEquals("[Errno 2] No such file or directory: '/tmp/slowfoottest/data/illegalfile'", str(e))
		self.req.handle('/legalfile', {'args':{}})
		self.assertEquals('read this', self.handlepsp_template[0])
		
	def testHandleOneTemplateOneIllegalFile(self):
		self.req.addPlugin(PREOPEN,self.MockIllegalFilePlugin())
		self.tempDataFileWithGC('do not read this', 'illegalfile')
		self.tempDataFileWithGC('a|<%%>|f', 'legaltemplate')
		#try:
		self.req.handle('/legaltemplate/illegalfile', {'args': {}})
		self.assertEquals("a|[Errno 2] No such file or directory: 'illegalfile'|f", ''.join(self.result))
		#	self.fail()
		#except IOError, e:
		#	self.assertEquals("[Errno 2] No such file or directory: '/tmp/slowfoottest/data/illegalfile'", str(e))

	def testHandleOneIllegalTemplateOneLegalFile(self):
		self.req.addPlugin(PREOPEN,self.MockIllegalFilePlugin())
		self.tempDataFileWithGC('read this', 'legalfile')
		self.tempDataFileWithGC('a<%%>f', 'illegaltemplate')
		try:
			self.req.handle('/illegaltemplate/legalfile', {'args': {}})
			self.fail()
		except IOError, e:
			self.assertEquals("[Errno 2] No such file or directory: '/tmp/slowfoottest/data/illegaltemplate'", str(e))

	def testHandleOneIllegalTemplateOneLegalTemplateOneLegalFile(self):
		self.req.addPlugin(PREOPEN,self.MockIllegalFilePlugin())
		self.tempDataFileWithGC('read this', 'legalfile')
		self.tempDataFileWithGC('c<%%>d', 'illegaltemplate')
		self.tempDataFileWithGC('a<%%>f', 'legaltemplate')
		try:
			self.req.handle('/legaltemplate/illegaltemplate/legalfile', {'args': {}})
			self.fail()
		except IOError, e:
			self.assertEquals("[Errno 2] No such file or directory: '/tmp/slowfoottest/data/illegaltemplate'", str(e))

	def testHandleOneLegalTemplateOneIllegalTemplateOneLegalFile(self):
		self.req.addPlugin(PREOPEN,self.MockIllegalFilePlugin())
		self.tempDataFileWithGC('read this', 'legalfile')
		self.tempDataFileWithGC('c<%%>d', 'illegaltemplate')
		self.tempDataFileWithGC('a<%%>f', 'legaltemplate')
		try:
			self.req.handle('/illegaltemplate/legaltemplate/legalfile', {'args': {}})
			self.fail()
		except IOError, e:
			self.assertEquals("[Errno 2] No such file or directory: '/tmp/slowfoottest/data/illegaltemplate'", str(e))
			
	def testHandleOneTemplateOneDataFile(self):
		self.tempDataFileWithGC('hel<%%>lo!', 'template')
		self.tempDataFileWithGC('data1', 'datafile1')
		try:
			self.req.handle('/template/datafile1', {'args': {}})
		finally:
			self.req.close()
		self.assertEquals('hel<%%>lo!', self.handlepsp_template[0])
		self.assertEquals('data1', self.handlepsp_data[0]['text'])
		self.assert_('last-modified' not in self.headers_out)

	def testHandleTwoTemplatesOneDataFile(self):
		self.tempDataFileWithGC('11<%%>11', 'template1')
		self.tempDataFileWithGC('22<%%>22', 'template2')
		self.tempDataFileWithGC('data', 'datafile')
		try:
			self.req.handle('/template1/template2/datafile', {'args': {}})
		finally:
			self.req.close()
		# This is what happens: datafile is fed to template2 and the result is fed to template1
		self.assertEquals(2, len(self.handlepsp_data))
		self.assertEquals('data', self.handlepsp_data[1]['text'])
		self.assertEquals('22<%%>22', self.handlepsp_template[1])
		self.assertEquals('1122data2211', ''.join(self.result))
		self.assert_('last-modified' not in self.headers_out)
		
	def testThreeTemplatesOneDataFile(self):
		self.tempDataFileWithGC('g<%%>d', 't1')
		self.tempDataFileWithGC('r<%%>l', 't2')
		self.tempDataFileWithGC('o<%%>e', 't3')
		self.tempDataFileWithGC('enev', 'd')
		try:
			self.req.handle('/t1/t2/t3/d', {'args': {}})
		finally:
			self.req.close()
		self.assertEquals('groeneveld', ''.join(self.result))
		self.assert_('last-modified' not in self.headers_out)
		
	def testIgnoreOtherTemplates(self):
		self.tempDataFileWithGC('janssen', 't1')
		self.tempDataFileWithGC('gro<%%>eld', 't2')
		self.tempDataFileWithGC('enev', 'd')
		try:
			self.req.handle('/t1/t2/d', {'args': {}})
		finally:
			self.req.close()
		self.assertEquals('janssen', ''.join(self.result))

	def testIgnoreOtherTemplatesDontCheckExistence(self):
		self.tempDataFileWithGC('janssen', 't1')
		self.tempDataFileWithGC('enev', 'd')
		try:
			self.req.handle('/t1/template_does_not_exist/d', {'args': {}})
		finally:
			self.req.close()
		self.assertEquals('janssen', ''.join(self.result))

	def testIgnoreOtherTemplatesDontCheckExistenceOfData(self):
		self.tempDataFileWithGC('janssen', 't1')
		self.req.handle('/t1/template_does_not_exist/data_does_not_exist_either', {'args': {}})
		self.assertEquals('janssen', ''.join(self.result))
		
	def testDefaultEditTemplate(self):
		os.path.isfile(self.testdir + '/data/edit') and os.remove(self.testdir + '/data/edit')
		self.tempDataFileWithGC('default edittemplate', 'edit', '')
		self.req.handle('/edit', {'args': {}})
		self.assertEquals('default edittemplate', ''.join(self.result))

	def testUseDefaultEditTemplate(self):
		os.path.isfile(self.testdir + '/data/edit') and os.remove(self.testdir + '/data/edit')
		os.path.isfile(self.testdir + '/data/edit') and os.remove(self.testdir + '/data/edit')
		self.tempDataFileWithGC('edit <%%>', 'edit', 'data')
		self.tempDataFileWithGC('this', 'this')
		try:
			self.req.handle('/edit/this', {'args': {}})
		finally:
			self.req.close()
		self.assertEquals('edit this', ''.join(self.result))

	def testDefaultEditTemplateOverridden(self):
		open(self.testdir + '/edit', 'w').write('default edittemplate')
		open(self.testdir + '/data/edit', 'w').write('changed edittemplate')
		self.req.handle('/edit', {'args': {}})
		self.assertEquals('changed edittemplate', ''.join(self.result))

	##### tests for psp methods #####
	def testUrl(self):
		self.tempDataFileWithGC('', 'test')
		stream = self.req._psp_url('file://' + pathname2url(self.testdir) + '/data/test')
		try:
			self.assert_(hasattr(stream, 'next'))
			self.assertEquals(1, len(self.req.openfiles))
		finally:
			stream.close()
		
	def testxml(self):
		xmlstream = StringIO('<?xml version="1.0"?><data><aap>jaap</aap></data>')
		xmlstream.geturl = lambda: 'url'
		info = self
		info.getdate = lambda d: 'date'
		xmlstream.info = lambda: info
		self.assert_(hasattr(xmlstream, 'info'))
		xml = self.req._psp_xml(xmlstream)
		self.assertEquals('jaap', xml.data.aap)

	def testtext(self):
		stream=StringIO('<?xml version="1.0"?><data><aap>jaap</aap></data>')
		text = self.req._psp_text(stream)
		self.assertEquals('<?xml version="1.0"?><data><aap>jaap</aap></data>', text)

	def testUrlNotPossible(self):
		self.assertRaises(OSError,self.req._psp_url,'file://no/way/this/exists')
	
	def testInclude(self):
		stream = StringIO('tekst, tekst, tekst')
		self.req.write('<begin>')
		self.req._psp_include(stream)
		self.req.write('<end>')
		self.assertEquals('<begin>', self.result[0])
		self.assertEquals('tekst, tekst, tekst', self.result[1])
		self.assertEquals('<end>', self.result[2])
		
	def testIncludeWithURL(self):
		self.tempDataFileWithGC('it is raining', 'test')
		stream = self.req._psp_include('file://' + pathname2url(self.testdir) +'/data/test')
		try: 
			self.assertEquals('it is raining', ''.join(self.result))
		finally:
			self.req.close()
		
	def testPipeWithBuffer(self):
		stream = StringIO('tekst, tekst, tekst\n' * 100)
		self.req._psp_include(stream)
		self.assertEquals(100, len(self.result))

	def testLastModified(self):
		self.uri = '/mies'
		self.tempDataFileWithGC('aap', 'mies')
		self.req.go()
		self.assertTimesAlmostEqual(time.gmtime(), email.Utils.parsedate(self.headers_out['last-modified']))
		
	def testLastModifiedWithNonexistingStuff(self):
		self.uri = '/mies/does_not_exist_as_far_as_i_know'
		self.tempDataFileWithGC('aap', 'mies')
		self.req.go()
		# file does not exist so the last-modified date is a bit in the future. +5
		self.assert_(time.time() < email.Utils.parsedate(self.headers_out['last-modified']))
	

	def testPSPhasAttributes(self):
		self.uri = '/mies'
		self.tempDataFileWithGC('<%%>', 'mies')
		self.req.go()
		self.assert_(callable(self.handlepsp_data[0]['asxml']))
		self.assert_(self.handlepsp_data[0]['asxml'] == self.req._psp_xml)
		self.assert_(self.handlepsp_data[0]['url'] == self.req._psp_url)
		self.assert_(self.handlepsp_data[0]['include'] == self.req._psp_include)	
		self.assert_(self.handlepsp_data[0]['escape_html'] == self.req._psp_escape_html)
		self.assert_(self.handlepsp_data[0]['escape_html2'] == self.req._psp_escape_html2)
		self.assert_(self.handlepsp_data[0]['remoteHost'] == self.req.remoteHost)
		self.assert_(self.handlepsp_data[0]['cutOff'] == self.req._psp_cutOff)
		self.assert_(self.handlepsp_data[0]['isUrl'] == isUrl)
		self.assert_(self.handlepsp_data[0]['prepareHeaders'] == self.req._prepareHeaders)
		self.assertEquals('', self.handlepsp_data[0]['text'])
		self.assert_(callable(self.handlepsp_data[0]['uuid']))
		self.assert_(self.handlepsp_data[0]['uuid'] == self.req.uuid)
		
	def testUUID(self):
		u = self.req.uuid()
		self.assert_(u)
		groups = u.split('-')
		self.assertEquals([8,4,4,4,12],map(len,groups))
		# 'd5582363-337d-43bb-a1cb-fa0ebad8a0c6'
		# random uuid is recognizable by:
		self.assert_('4' == groups[2][0])
		self.assert_(groups[3][0] in '89ab')
		
		
	def testTarget(self):
		self.req.target('/data/target')
		self.req.write('Target stuff')
		self.req.close()
		self.assertEquals('Target stuff', open(self.slowfootdata + '/target').read())
		
	def testRetarget(self):
		self.req.write('something')
		self.req.flush()
		self.req.target('/data/target')
		self.req.write('Target stuff')
		self.req.flush()
		self.req.target('/data/bla')
		self.req.write('bla')
		self.req.flush()
		self.req.target()
		self.req.write(' else')
		self.req.close()
		self.assertEquals('Target stuff', open(self.slowfootdata + '/target').read())
		self.assertEquals('bla', open(self.slowfootdata + '/bla').read())

	def testTargetStream(self):
		path = self.tempDataFileWithGC('het werkt niet!, ', 'testTargetStream')
		f = open(path, 'a')
		try:
			self.req.target(f)
			self.req.write('het werkt!')
		finally:
			f.close()
		f = open(path)
		try:
			s = f.read()
		finally:
			f.close()
		self.assertEquals('het werkt niet!, het werkt!', s)
		self.assertEquals(1, len(self.req.openfiles))

		
	def testEscapeHTML2String(self):
		result = self.req._psp_escape_html2('escape this: <>')
		self.assertEquals('escape this: &lt;&gt;', result)
		result = self.req._psp_escape_html2("""escape "this & that'""")
		self.assertEquals('escape &quot;this &amp; that\'', result)		

	def testEscapeHTMLString(self):
		resultNone = self.req._psp_escape_html('escape this: <>')
		self.assertEquals('escape this: &lt;&gt;', self.result[0])
		print "\nTJ/JJ: Bookmark: escape_html still writes to request directly, use escape_html2"
		resultNone = self.req._psp_escape_html("""escape "this & that'""")
		self.assertEquals('escape &quot;this &amp; that\'', self.result[1])		

	def testNow(self):
		date = self.req._psp_now('%Y/%m/%d')
		self.assertTrue(re.compile('200\d/[01][0-9]/[0-3][0-9]').match(date))
		date = self.req._psp_now()
		self.assertTrue(re.compile('200\d-[01][0-9]-[0-3][0-9]').match(date))

	def testArgs(self):
		self.setUp()
		self.tempDataFileWithGC('hel<%%>lo!', 'template')
		data = {'args': {'argument': 'value'}}
		self.req.handle('/template?a=b', data)
		self.assertEquals({'argument': 'value', 'a': 'b'}, data['args'])

	def testPSPCaching(self):
		path = self.tempdir + '/slowfoot_psp_aUniqueName'
		os.path.exists(path) and os.remove(path)
		self.assert_(not os.path.exists(path))
		
		self.headers_out['last-modified'] = formatdate(0)
		
		self.req._psp_psp('template1', 'aUniqueName')
		self.assertEquals(self.tempdir + '/slowfoot_psp_aUniqueName', self.handlepsp_templatefiles[0])
		self.assertEquals('template1', self.result[0])
		
		self.req._psp_psp('template2', 'aUniqueName')
		self.assertEquals('template1', self.result[1]) # template cache used

		d = getModifiedDate(self.tempdir + '/slowfoot_psp_aUniqueName')
		d = d[:5] + (d[5] + 1,) + d[6:] + (0,)# advance 1 second
		self.headers_out['last-modified'] = formatdate(mktime_tz(d))
		self.req._psp_psp('template2', 'aUniqueName')
		self.assertEquals('template2', self.result[2])

	def assertTimesAlmostEqual(self, date1, date2):
		# the last 3 fields are not interesting (weekday, yearday and daylightsavingtime)
		date1 = date1[:6] + (0,0,0)
		date2 = date2[:6] + (0,0,0)
		self.assertTrue(abs(time.mktime(date1) - time.mktime(date2)) <= 1, '%s != %s' % (str(date1), str(date2)) )

	def testGetModifiedDateFromFile(self):
		fd, path = tempfile.mkstemp()
		os.close(fd)
		date0 = time.gmtime()
		date1 = getModifiedDate(path)
		date2 = getModifiedDateFromHeader(urlopen('file:' + path).info())
		self.assertTimesAlmostEqual(date0, date1)
		self.assertTimesAlmostEqual(date1, date2)
					
	def testGetModifiedDataFromNonExistingFile(self):
		fname = '/unexisting/directory/that/nobody/has/on/his/or/her/system'
		self.assert_(not os.path.exists(fname))
		date = getModifiedDate(fname)
		currenttime = time.mktime(time.gmtime())
		self.assertAlmostEqual(time.mktime(date),currenttime+5, 2)
		self.assert_(time.mktime(date) > currenttime, "Time should be in the future")
	
	def testGetModifiedDateFromHeaderWithNoDate(self):
		date = getModifiedDateFromHeader({})
		currenttime = time.mktime(time.gmtime())
		self.assertAlmostEqual(time.mktime(date),currenttime+5, 2)
		self.assert_(time.mktime(date) > currenttime, "Time should be in the future")

	def testRequestAsIterator(self):
		iter = self.req.__iter__()
		self.assertEquals(self.req, iter)
		self.readlineResult = 'mies\n'
		line = iter.next()
		self.assertEquals('mies\n', line)

	def testIncludeStream(self):
		from request import ImplicitStreamStreamer
		stream = ImplicitStreamStreamer(self.req, StringIO('stream this when str() is called'))
		self.req.write(stream)
		self.assertEquals('stream this when str() is called', ''.join(self.result))
		
	def testStreamNonStreamSuchAsHTTPResponseObjects(self):
		from request import ImplicitStreamStreamer
		out = StringIO()
		brokenstream = StringIO('aap noot mies')
		brokenstream.next = None
		brokenstream.__iter__ = None
		stream = ImplicitStreamStreamer(out, brokenstream)
		str(stream)
		self.assertEquals('aap noot mies', out.getvalue())
		
	def testImplicitStreamStreamerNameForCaching(self):
		from request import ImplicitStreamStreamer
		import amaracache
		stream = ImplicitStreamStreamer(None, None, 'aap')
		self.assertEquals('aap', amaracache.getKeyFor(stream))

	def testFilePath(self):
		self.assertEquals(os.path.join(self.document_root(),'data','tosti'), self.req.filepath('tosti'))
		self.assertEquals(os.path.join(self.document_root(),'data','pindakaas'), self.req.filepath('pindakaas'))
		self.assertEquals(self.req.filepath, self.req.copyData()['filepath'])
		
	def testDeleteFile(self):
		filepath = self.req.filepath('tosti')
		open(filepath,'w').close()
		self.assert_(os.path.isfile(filepath))
		self.req.deletefile('tosti')
		self.assert_(not os.path.isfile(filepath))
		self.assertEquals(self.req.deletefile, self.req.copyData()['deletefile'])

	def testDontDeleteFilesInOtherDirectories(self):
		filepath = os.path.join(self.req.document_root(), 'ham')
		open(filepath,'w').close()
		self.assert_(os.path.isfile(filepath))
		self.req.deletefile('../ham')
		self.assert_(os.path.isfile(filepath))

	def testRequireValidUserStep1(self):
		self.assertEquals('', self.req.headers_in.get('Authorization',''))
		try:
			self.req.requireValidUser('testrealm')
			self.fail()
		except apache.SERVER_RETURN, e:
			self.assertEquals('Basic realm="testrealm"', self.err_headers_out['WWW-Authenticate']) 

	def testRequireValidUserSucces(self):
		from base64 import encodestring
		self.req._authenticateUser = lambda username, pw: username
		self.req.headers_in['Authorization'] = 'Basic ' + encodestring('username:password')
		username = self.req.requireValidUser('testrealm')
		self.assertEquals('username', username)

	def shunted_authenticateUserForFail(self, username, password):
		raise apache.SERVER_RETURN, apache.HTTP_UNAUTHORIZED

	def testRequireValidUserFail(self):
		from base64 import encodestring
		self.req._authenticateUser = self.shunted_authenticateUserForFail
		self.req.headers_in['Authorization'] = 'Basic ' + encodestring('username:password')
		try:
			username = self.req.requireValidUser('testrealm')
			self.fail()
		except apache.SERVER_RETURN:
			pass
			
	def testRequireValidUserChecksSession(self):
		self.req.session = {'user':account.Account('admin')}
		try:
			userAccount = self.req.requireValidUser('testrealm')
		except apache.SERVER_RETURN:
			self.fail()

	def testInitSession(self):
		self.assertTrue(hasattr(self.req, 'session'))
		self.assertFalse(hasattr(self.req, 'this attr does not exist'))

	def testCutOff(self):
		self.assertEquals('aa...', self.req._psp_cutOff('aap', chars=2))
		self.assertEquals('aa bb...', self.req._psp_cutOff('aa bb cc dd', chars=7))
		self.assertEquals('aa bb cc...', self.req._psp_cutOff('aa bb cc dd', chars=9))
		self.assertEquals('aabbcc...', self.req._psp_cutOff('aabbccdd', chars=6))
		
	def testIsUrl(self):
		self.assertTrue(isUrl('http://www.example.org/'))
		self.assertTrue(isUrl('https://www.example.org/'))
		self.assertTrue(isUrl('ftp://www.example.org/'))
		self.assertFalse(isUrl('www.example.org/'))
		
	def getMethodFromData(self, methodName):
		# pruts pruts
		self.uri = '/mies'
		self.tempDataFileWithGC('<%%>', 'mies')
		self.req.go()
		return self.handlepsp_data[0][methodName]

		
	def testUrlencode(self):
		urlencodeMethod = self.getMethodFromData('urlencode')
		
		self.assertEqualsQuery('', urlencodeMethod(wrapp({})))
		self.assertEqualsQuery('aa=bb', urlencodeMethod(wrapp({'aa':wrapp(['bb'])})))
		self.assertEqualsQuery('aa=bb', urlencodeMethod({'aa':['bb']}))
		self.assertEqualsQuery('aa=bb&aa=cc', urlencodeMethod({'aa':['bb','cc']}))
		self.assertEqualsQuery('aa=bb', urlencodeMethod({'aa':'bb'}))
		self.assertEqualsQuery('aa=bb&cc=dd&cc=ee', urlencodeMethod({'aa':'bb','cc':['dd','ee']}))
		self.assertEqualsQuery('aa=', urlencodeMethod({'aa':''}))
		
	def testChecked(self):
		checkedMethod = self.getMethodFromData('checked')
		self.assertEquals('checked', checkedMethod('',''))
		self.assertEquals('checked', checkedMethod('abc','abc'))
		self.assertEquals('', checkedMethod('def','abc'))
		self.assertEquals('', checkedMethod('abc',''))
	
	def testSelected(self):
		selectedMethod = self.getMethodFromData('selected')
		self.assertEquals('selected', selectedMethod('',''))
		self.assertEquals('selected', selectedMethod('abc','abc'))
		self.assertEquals('', selectedMethod('def','abc'))
		self.assertEquals('', selectedMethod('abc',''))

	def callPrepareHeaders(self, prepareHeadersMethod):
		#Normal use: prepareHeaders will be called in a template
		# for testing we will run prepareHeaders just after rendering.
		self.uri = '/mies'
		self.tempDataFileWithGC('aap', 'mies')
		self.req.go()
		prepareHeadersMethod and prepareHeadersMethod()
		return self.req.headers_out
		  
	def testNoPrepareHeaders(self):
		headers = self.callPrepareHeaders(None)
		self.assertTrue('last-modified' in headers)
		
	def testPrepareHeaders(self):
		headers = self.callPrepareHeaders(self.req._prepareHeaders)
		self.assertFalse('last-modified' in headers)
		self.assertEquals('-1', headers['Expires'])
		self.assertEquals('no-cache', headers['Pragma'])
		self.assertEquals('no-cache', headers['Cache-Control'])

	def testPrepareHeadersForQuery(self):
		headers = self.callPrepareHeaders(lambda: self.req._prepareHeaders('private'))
		self.assertFalse('last-modified' in headers)
		self.assertEquals('private', headers['Cache-Control'])
		self.assertFalse('Expires' in headers)
		self.assertFalse('Pragma' in headers)
		
	def assertEqualsQuery(self, left, right):
		"""assert equality with order not important"""
		self.assertEquals(sorted(left.split('&')), sorted(right.split('&')))
		
	def testRemoteHost(self):
		self.assertEquals('10.0.0.1', self.req.remoteHost())
		
	# self shunt
	def get_remote_host(self, flags):
		return '10.0.0.1'
	
from UserDict import DictMixin
class HeadersDict(DictMixin):
	"""Case IN sensitive dictionary for test purposes.
Simulates the headers in a real life situtation, they are
also case-insensitive"""
	def __init__(self):
		self.__data = {}
		self._key = lambda key:hasattr(key, 'lower') and key.lower() or key
		
	def __delitem__(self, key):
		return self.__data.__delitem__(self._key(key))
	
	def __setitem__(self, key, value):
		return self.__data.__setitem__(self._key(key), value)
	
	def __getitem__(self, key):
		return self.__data.__getitem__(self._key(key))

	def keys(self):
		return self.__data.keys()
	

import unittest
if __name__ == '__main__': unittest.main()
