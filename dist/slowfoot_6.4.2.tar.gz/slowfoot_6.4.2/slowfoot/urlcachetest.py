#!/usr/bin/env python
## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import unittest
from urlcache import URLCache, CachedURL
import urllib2, tempfile, os, rfc822, time
from cStringIO import StringIO
from cq2date import GMTDate, gmtNow

filecontents = """A temporary file.
with multiple
lines
with multiple
lines
with multiple
lines
with multiple
lines"""

class URLCacheTest(unittest.TestCase):
	def setUp(self):
		self.handle = tempfile.NamedTemporaryFile('a+')
		self.tmpname = self.handle.name
		self.handle.write(filecontents)
		self.handle.flush()
		self.handle.seek(0)
		self.cache = URLCache()
		self.tmpurl = 'file:' + self.tmpname
		self.mockdate = None
		self.mock_open_called = 0
		self.closed = False

	def updateTestFile(self, contents):
		hnd = open(self.tmpname,'w')
		hnd.write(contents)
		hnd.flush()
		hnd.close()
		
	def testExceptionsArePassedOn(self):
		self.assertExceptionsArePassedOn('file:/aNonExistingFile')
		self.assertExceptionsArePassedOn('http://a.b.c/')
		
	def assertExceptionsArePassedOn(self, bogusURL):
		desiredException = None
		try:
			urllib2.urlopen(bogusURL)
		except Exception, e:
			desiredException = e
		try:
			self.cache.get(bogusURL)
		except Exception, e:
			self.assertEquals(desiredException.__class__, e.__class__)

	def testKeepOldDataOnException(self):
		self.cache._open = self.mock_open
		
		grace = .1
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(grace)
		
		self.updateTestFile('cats and dogs')
		self.assertEquals('cats and dogs', self.cache.get(self.tmpurl).read())
		
		time.sleep(10 * grace)
		
		self.cache._open = self.mock_open_error
		self.updateTestFile('mice and frogs')
		self.assertEquals('cats and dogs', self.cache.get(self.tmpurl).read())
		

	def testIsReallyCache(self):
		self.cache._open = self.mock_open
		self.mock_open_called = 0
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(60)
		self.assertEquals(filecontents, self.cache.get(self.tmpurl).read())
		self.assertEquals(1, self.mock_open_called)
		self.assertEquals(filecontents, self.cache.get(self.tmpurl).read())
		self.assertEquals(1, self.mock_open_called)

	def testURLWithoutExpirationIsRefetched(self):
		self.cache._open = self.mock_open
		self.mockdate = None
		self.updateTestFile('aap')
		self.assertEquals('aap', self.cache.get(self.tmpurl).read())
		
		self.updateTestFile('mies')
		self.assertEquals('mies', self.cache.get(self.tmpurl).read())
		
	def testNastyDeleteSceneraio(self):
		grace = .1
		self.cache._open = self.mock_open
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(grace)
		
		self.updateTestFile('aap')
		self.assertEquals('aap', self.cache.get(self.tmpurl).read())
		self.mockdate = None
		time.sleep(grace * 10)
		
		self.updateTestFile('noot')
		self.assertEquals('noot', self.cache.get(self.tmpurl).read())
		
		
	def testURLsExpire(self):
		self.cache._open = self.mock_open
		grace = .1
		
		self.updateTestFile('aap')
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(grace)

		self.assertEquals('aap', self.cache.get(self.tmpurl).read())
		
		time.sleep(10 * grace)
		self.updateTestFile('mies')
		self.assertEquals('mies', self.cache.get(self.tmpurl).read())
				
	def testCachedURLsAreURLLikeStreams(self):
		self.cache._open = self.mock_open
		url = self.cache.get(self.tmpurl)
		self.assertEquals(filecontents, url.read())
		self.assertEquals('', url.read())
		try:
			url.reset()
			self.fail()
		except AttributeError:
			pass
	
	def testCachedURLsAreIndependent(self):
		self.cache._open = self.mock_open
 		url1 = self.cache.get(self.tmpurl)
		url2 = self.cache.get(self.tmpurl)
		a = url1.read(1)
		b = url2.read(1)
		while a or b:
			self.assertEquals(a, b)
			a = url1.read(1)
			b = url2.read(1)
		self.assertEquals('', a)
		self.assertEquals(a, b)
					
	def testCachedURLsHaveURLInterface(self):
		self.cache._open = self.mock_open
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(100)
 		url = self.cache.get(self.tmpurl)
		self.assert_(hasattr(url, "info"))
		self.assert_(url.info().getdate("expires"))
		self.assertEquals(self.tmpurl, url.geturl())
		self.assertEquals(filecontents.split('\n')[0] + '\n', url.readline())
		
	def testCachedURLsAreIndependentIter(self):
		self.cache._open = self.mock_open
 		url1 = self.cache.get(self.tmpurl)
		url2 = self.cache.get(self.tmpurl)
		self.assertEquals(''.join(url1), ''.join(url2))
	
	def testCachedURLsHaveIndependentRead(self):
		self.cache._open = self.mock_open
 		url1 = self.cache.get(self.tmpurl).readline()
		url2 = self.cache.get(self.tmpurl).readline()
		self.assertEquals(url1, url2)
		
	def testReadAndTell(self):
		self.handle.seek(0)
		a = self.handle.next()
		self.assertEquals(97L, self.handle.tell())
		
	def testCachingIsLazy(self):
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(60)
		self.cache._open = self.mock_open2
 		url1 = self.cache.get(self.tmpurl)
		url2 = self.cache.get(self.tmpurl)
		self.handle.seek(0)
		a = url1.read(3)
		self.assertEquals(97L, self.handle.tell())
		b = url2.read(10)
		self.assertEquals(97L, self.handle.tell())
	
	def testNoMocking(self):
		self.assertEquals(filecontents, self.cache.get(self.tmpurl).read())
		self.assertEquals(filecontents, self.cache.get(self.tmpurl).read())
		
	def testHeadersAreUsed(self):
		self.cache._open = self.mock_open
		self.cache.get(self.tmpurl, {"aap": "noot"})
		self.assertEquals("noot", self.mock_headers["aap"])
		
	def testStuffWithHeadersIsNotCached(self):
		self.cache._open = self.mock_open
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(60)
		
		self.cache.get(self.tmpurl, {"aap": "noot"})
		self.assertEquals(1, self.mock_open_called)
		self.assertEquals("noot", self.mock_headers["aap"])
		
		self.cache.get(self.tmpurl, {"aap": "mies"})
		self.assertEquals(2, self.mock_open_called)
		self.assertEquals("mies", self.mock_headers["aap"])
		
	def testCloseIsSafe(self):
		self.cache._open = self.mock_open
		self.mock_open_called = 0
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(60)
		ref = self.cache.get(self.tmpurl)
		self.assertEquals(filecontents, ref.read())
		self.assert_(ref.fp)
		ref.close()
		self.assert_(not ref.fp)
		self.assertEquals(filecontents, self.cache.get(self.tmpurl).read())
		
	def testStringNogNietHelemaalUitgelezen(self):
		self.cache._open = self.mock_open
		self.mock_open_called = 0
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(60)
		ref = self.cache.get(self.tmpurl)
		self.assertEquals(filecontents[:10], ref.read(10))
		self.assert_(ref.fp)
		ref.close()
		self.assert_(not ref.fp)
		self.assertEquals(filecontents, self.cache.get(self.tmpurl).read())
			
	def xxxxtestVeryLargeFilesAreNotCached(self):
		"""Erik said it was ok to not have this (yet?). Teddy agreed."""
		considered_large = pow(2, 7)
		self.cache.maxfilesize = considered_large
		filecontents = 'x' * (considered_large + 1)
		self.updateTestFile(filecontents)
		self.mockdate = gmtNow()
		self.mockdate.addSeconds(60)
		
		self.cache._open = self.mock_open2
 		url1 = self.cache.get(self.tmpurl)
		self.assertEquals(filecontents, url1.read())
		self.updateTestFile('aap')
		url2 = self.cache.get(self.tmpurl)
		self.assertEquals('aap', url2.read())
				
	
	#self shunts:
	def mock_open(self, urlstr, headers = {}):
		self.mock_open_called += 1
		self.mock_headers = headers
		result = urllib2.urlopen(urlstr)
		if self.mockdate:
			result.headers['Expires'] = self.mockdate.asRfc822()
		return result
		
	def mock_open2(self, urlstr, headers = {}):
		return self
	
	def mock_open_error(self, urlstr, headers = {}):
		raise urllib2.HTTPError(None,None,None,None, None)
	
	def info(self):
		return self
	
	def getdate(self, key):
		return self.mockdate.asTuple()
	
	def next(self):
		result = self.handle.next()
		return result
		
if __name__ == '__main__':
	unittest.main()
	
