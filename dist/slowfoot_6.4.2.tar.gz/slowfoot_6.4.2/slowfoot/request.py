## begin license ##
#
#    Slowfoot is an integration system for web-based applications.
#    Copyright (C) 2005, 2006 Seek You Too B.V. (CQ2) http://www.cq2.nl
#
#    This file is part of Slowfoot.
#
#    Slowfoot is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    Slowfoot is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with Slowfoot; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
## end license ##

import sys, os, stat, tempfile, cgi, base64, time, xml.sax.saxutils, re, string
from cStringIO import StringIO
from urllib import urlencode, pathname2url
from email.Utils import parsedate, mktime_tz, formatdate
from threading import Lock

from amaracache import AmaraCache
from cq2utils.wrappers import wrapp
from slowfooturl import SlowfootURL
import slowconfig, slowfooturl
from headerswrapper import HeadersWrapper
import headerswrapper
import testsupport
from mod_python import apache
from Ft.Lib.Uuid import UuidAsString, GenerateUuid

amaracache = AmaraCache()
pspCacheLock = Lock()

from magicstream import MagicStream
from slowfootstorage import SlowfootStorage
storage = None

#Events plugin name.
PREOPEN='PREOPEN'

class DoesNotExist:
	def __init__(self, exc):
		self.exc = exc
		
	def __getattr__(self, attr):
		raise self.exc
		
	def __str__(self):
		return str(self.exc)

class TemplateCall:
	def __init__(self, templatefilename, outer, data):
		self.outer = outer
		self.templatename = templatefilename
		self.data = data

	def __str__(self):
		self.outer.handlepsp(self.outer, self.templatename, self.data)
		return ''


class ImplicitStreamStreamer:
	def __init__(self, target, stream, uuid = None):
		self.target = target
		self.stream = stream
		if uuid: self.uuid = uuid
	
	def __str__(self):
		for line in self:
			self.target.write(line)
		return ''
			
	def __getattr__(self, name):
		return getattr(self.stream, name)

	def __iter__(self):
		return self
		
	def next(self):
		line = self.stream.read(1024)
		if not line: raise StopIteration()
		return line

def getModifiedDate(filename):
	return time.gmtime(storage.getModifiedDate(filename))[:6] + (0,0,0)

def getModifiedDateFromHeader(headers):
	"Return the lastmodified time, if that fails return a time in the future"
	return parsedate(headers.get('last-modified', '')) or time.gmtime(time.time()+5)

def parseUri(uri):
	components = uri.split('/')
	if len(components) > 2:
		return components[1:-1], components[-1]
	#if len(components) == 2:
	return [components[1] or 'index.html'], None

def parseIncludeUri(uri):
	splitted = uri.split('?')
	return (splitted+[''])[:2]

def set(obj, val):
	obj.content_type = val

urlregexp = re.compile('(file|ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/')
def isUrl(s):
        return urlregexp.match(s) != None

class Request:
	def __init__(self, req, psphandler, util, login, sessionretrieve=None):
		global storage
		if not storage:
			storage = SlowfootStorage(req.document_root())

		self.psputil = util
		self._handlepsp = psphandler
		self._plugins = {}
		self.document_root = req.document_root
		self.headers_in = req.headers_in
		self.connection = req.connection
		self.server = req.server
		self.register_cleanup = req.register_cleanup
		self.hlist = req.hlist
		self.uri = req.uri
		self.headers_out = req.headers_out
		self.get_options = req.get_options
		self.log_error = req.log_error
		self.args = req.args
		self.dest = req
		self.req = req
		self.openfiles = []
		self._sessionretrieve=sessionretrieve
		#self.filename = hasattr(file, 'name') and file.name or ''
		self.method = req.method
		
		# per request stuff
		data = {'args': wrapp(self.req.args and util.parse_qs(self.req.args) or {})}
		self.req.get_basic_auth_pw() # force req to create user attr
		data['user'] = self.req.user
		data['input'] = ImplicitStreamStreamer(self, self) #ahum
		data['asform'] = self.getFormData
		#data['form'] = self.req.method == 'POST' and self.getFormData() or ''
		self.setContent_type = lambda type: set(self.req, type)
		data['type'] = self.setContent_type
		data['referer'] = self.headers_in.get('referer', '')
		data['header'] = HeadersWrapper(self.headers_in, self.headers_out)

		#static stuff
		data['post'] = self._psp_post
		data['asxml'] = self._psp_xml
		data['url'] = self._psp_url
		data['now'] = self._psp_now
		data['get'] = data['url']
		data['uuid'] = self.uuid
		data['include'] = self._psp_include
		data['escape_html'] = self._psp_escape_html
		data['escape_html2'] = self._psp_escape_html2
		data['cutOff'] = self._psp_cutOff
		data['isUrl'] = isUrl
		data['html'] = data['escape_html']
		data['psp'] = self._psp_psp
		data['urlencode'] = lambda u:urlencode(u, True)
		data['base64'] = base64.encodestring
		data['escape_xml'] = lambda x: self.write(xml.sax.saxutils.escape(str(x)))
		data['redirect'] = lambda url: util.redirect(self.req, str(url))
		data['files'] = storage.glob
		data['target'] = lambda url = None: self.target(url)
		data['requireValidUser'] = self.requireValidUser
		data['remoteHost'] = self.remoteHost
		data['uri'] = slowfooturl.uri
		data['filepath'] = self.filepath	
		data['deletefile'] = self.deletefile
		data['assertEquals'] = testsupport.assertEquals
		data['prepareHeaders'] = self._prepareHeaders
		data['checked'] = lambda x, y: x == y and 'checked' or ''
		data['selected'] = lambda x, y: x == y and 'selected' or ''

		self.____data = data

	def __getattr__(self, name):
		""" This method makes sure mod_python (psp.py) does NOT make sessions. When it does so,
		    it locks the session, which renders it unusable for Slowfoot."""
		if name == 'session':
			self.session = self._sessionretrieve(self.req)
			return self.session
		raise AttributeError(name)
		
	def getSession(self):
		return self.session
			
	def handlePreOpenPlugins(self, path):
		for plug in self.getPlugins(PREOPEN):
			plug.handle(self, path)
	
	def getPlugins(self, event):
		return self._plugins.get(event, [])
			
	def addPlugin(self, event, plugin):
		eventplugins = self._plugins.get(event, [])
		eventplugins.append(plugin)
		self._plugins[event]=eventplugins
	
	def handlepsp(self, req, path, data):
		self.handlePreOpenPlugins(path)
		self._handlepsp(req, path, data)
		
	def read(self, len = -1):
		return self.req.read(len)

	def __iter__(self):
		return self

	def next(self):
		line = self.req.readline()
		if not line: raise StopIteration
		return line

	def readline(self, len = -1):
		return self.req.readline(len)

	def getFormData(self, stream):
		fd = self.psputil.FieldStorage(stream)
		return wrapp(fd)
		
	def go(self):
		try:
			file = self.req.uri.split('/')[-1]
			if file:
				self.addModifiedHeaderFromFile(storage.getFullPath(file))
			self.handle(self.req.uri, self.____data)
		finally:
			self.close()
		
	def parseUriAndArgs(self, uri):
		splitted = parseIncludeUri(uri)
		moreargs = self.psputil.parse_qs(splitted[1])
		return parseUri(splitted[0]) + (moreargs,)

	def addModifiedHeaderFromFile(self, name):
		modified_date = storage.getModifiedDate(name)
		date = formatdate(modified_date)
		self.dest.headers_out['last-modified'] = date

	def handle(self, uri, data):
		templatenames, filename, args = self.parseUriAndArgs(uri)
		data['args'].update(args)
		data['text'] = ''
		data['xml'] = wrapp({})
		if filename:
			data['args']['name'] = filename
			
			try:
				self.handlePreOpenPlugins(filename)
				instream = MagicStream(storage.opendatastream(filename))
				self.openfiles.append(instream)
				if instream.xml:
					data['xml'] = self._psp_xml(instream)
				else:
					data['text'] = instream.read()
			except:
				dne = DoesNotExist(sys.exc_value)
				data['text'] = dne
				data['xml'] = dne

		mimetype =  'text/html; charset=utf-8'
		self.setContent_type( str(mimetype))		
		
		if len(templatenames) > 1:
			templatenames.reverse()
			for templatename in templatenames:
				text = TemplateCall(storage.getFullPath(templatename), self, data.copy())
				data['text'] = text
			str(text) # implicitly streams itself to fake PSP
		else:
			path = storage.getFullPath(templatenames[0])
			self.handlepsp(self, path, data)

	def write(self, text, flush = 0):
		self.dest.write(text)
		
	def flush(self):
		self.dest.flush()
	
	def close(self):
		map(lambda aFile: aFile.close(), self.openfiles)
		self.openfiles=[]
		
	def target(self, url = None):
		if isinstance(url, basestring):
			self.dest = storage.opendatastream(url, 'wb')
			self.openfiles.append(self.dest)
		elif isinstance(url, file):
			self.dest = url
			self.openfiles.append(url)
		else:
			self.dest = self.req

	def uuid(self):
		return UuidAsString(GenerateUuid())
	
	def copyData(self):
		data = self.____data.copy()
		data['args'] = wrapp(self.____data['args'].copy())
		return data


	########## Methods for Templates ##############

	def _psp_psp(self, text, aUniqueTemplateName, args = None, lastModified = None):
		
		lastModified = lastModified or getModifiedDateFromHeader(self.headers_out)
		data = self.copyData()
		if args:
			data.update(args)
		filename = tempfile.gettempdir() + '/slowfoot_psp_' + aUniqueTemplateName
		if not os.path.isfile(filename) or lastModified > getModifiedDate(filename):
			fd, path = tempfile.mkstemp()
			os.write(fd, str(text))
			os.close(fd)
			if os.name == 'nt':
				try:
					pspCacheLock.acquire()
					if os.path.exists(filename):
						os.remove(filename)
					os.rename(path, filename) # NOT atomic!
				finally:
					pspCacheLock.release()
			else:
				os.rename(path, filename) # atomic!

		self.handlepsp(self, filename, data)

	def _psp_url(self, url):
		headers = {}
		if not isUrl(url):
			#url = 'file://' + self.datafilename(url)
			url = slowconfig.localhosturl + url
			headers = self.headers_in
		stream = SlowfootURL(url, headers)
		self.openfiles.append(stream)
		return stream
		
	def _psp_xml(self, stream):
		return wrapp(amaracache.get(stream))
		
	def _psp_now(self, format='%Y-%m-%d'):
		return time.strftime(format)

	def _psp_text(self, stream):
		return stream.read()

	def _psp_include(self, stream):
		if isinstance(stream, basestring):
			if stream.startswith('/'):
				self.handle(stream, self.copyData())
				return
			else:
				stream = self._psp_url(stream)
		for buffer in stream:
			self.dest.write(buffer)
		return ''
		
	def _psp_cutOff(self, string, chars=100):
		if len(string) < chars:
			return string
		short = string[:chars]
		return (' ' in short and short[:(short.rindex(' '))] or short)+'...'
	
	def _psp_escape_html2(self, source):
		return cgi.escape(str(source)).replace('"', "&quot;")

	def _psp_escape_html(self, source):
		self.write(self._psp_escape_html2(source))

	def _psp_post(self, url, stream):
		connection = SlowfootURL(url, self.headers_in)
		postdata = isinstance(stream, basestring) and stream or stream.read()
		resultStream = connection.post(postdata)
		wrappedStream = ImplicitStreamStreamer(self.dest, resultStream, url)
		self.openfiles.append(wrappedStream)
		return wrappedStream

	def _prepareHeaders(self, type='no-cache'):
		"""Prepare headers for better performance.
Setting headers for Internet Explorer comes very strict, and not quite obvious.
There are two modes:
- 'no-cache': settings for normal pages
- 'private': settings for a page with generated context by e.g. a search engine.
"""
		del(self.headers_out['Last-Modified'])
		if 'no-cache' == type:
			self.req.headers_out['Cache-Control'] = 'no-cache'
			self.req.headers_out['Expires'] = '-1'
			self.req.headers_out['Pragma'] = 'no-cache'
		elif 'private' == type:
			self.req.headers_out['Cache-Control'] = 'private'

	def filepath(self, filename):
		return os.path.join(self.document_root(),'data',filename)
	
	def deletefile(self, filename):
		filepath = self.filepath(filename)
		if os.path.normpath(filepath).startswith(self.filepath('')):
			os.remove(filepath)

	def _authenticateUser(self, user, password):
		import account
		try:
			userAccount = account.login(user, password)
			self.getSession()['user'] = userAccount
			return userAccount
		except account.AccountException, e:
			raise apache.SERVER_RETURN, apache.HTTP_UNAUTHORIZED
	
	def remoteHost(self):
		NOLOOKUP = 2 #apache.REMOTE_NOLOOKUP
		return self.req.get_remote_host(NOLOOKUP)
	
	def requireValidUser(self, realm):
		session = self.getSession()
		userAccount = session and session.get('user', None) or None
		if not userAccount:
			authorization = self.headers_in.get('Authorization','')
			if not authorization:
				self.req.err_headers_out['WWW-Authenticate'] = 'Basic realm="%s"' % realm
				raise apache.SERVER_RETURN, apache.HTTP_UNAUTHORIZED
		
			from base64 import decodestring
			user, password = decodestring(authorization[len('Basic '):]).split(':',1)
			userAccount = self._authenticateUser(user, password)
		return userAccount

