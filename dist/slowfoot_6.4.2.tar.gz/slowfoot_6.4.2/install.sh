#!/bin/bash
cd $(dirname $0)/slowfoot/install
./install.sh $*
